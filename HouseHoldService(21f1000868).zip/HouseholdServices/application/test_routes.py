import unittest
from flask import Flask, jsonify
from flask_jwt_extended import create_access_token, JWTManager, get_jwt_identity
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
app.config['JWT_SECRET_KEY'] = 'super-secret'
db = SQLAlchemy(app)
jwt = JWTManager(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    role = db.Column(db.String(80), nullable=False)

class Professional(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    approval_status = db.Column(db.String(80), nullable=False)

@auth_bp.route('/admin/approve-professional/<int:id>', methods=['POST'])
@jwt_required()
def approve_professional(id):
    current_user = get_jwt_identity()
    user = User.query.filter_by(id=current_user).first()
    
    if user.role != 'admin':
        return jsonify({"msg": "Admin access required"}), 403

    professional = Professional.query.get_or_404(id)
    professional.approval_status = 'approved'
    db.session.commit()
    
    return jsonify({"msg": "Professional approved successfully"}), 200

class TestApproveProfessional(unittest.TestCase):
    def setUp(self):
        self.app = app.test_client()
        self.app_context = app.app_context()
        self.app_context.push()
        db.create_all()
        self.admin_user = User(id=1, role='admin')
        self.regular_user = User(id=2, role='user')
        self.professional = Professional(id=1, approval_status='pending')
        db.session.add(self.admin_user)
        db.session.add(self.regular_user)
        db.session.add(self.professional)
        db.session.commit()
        self.admin_token = create_access_token(identity=self.admin_user.id)
        self.user_token = create_access_token(identity=self.regular_user.id)

    def tearDown(self):
        db.session.remove()
        db.drop_all()
        self.app_context.pop()

    def test_admin_approve_professional(self):
        response = self.app.post('/admin/approve-professional/1', headers={'Authorization': f'Bearer {self.admin_token}'})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json, {"msg": "Professional approved successfully"})
        professional = Professional.query.get(1)
        self.assertEqual(professional.approval_status, 'approved')

    def test_non_admin_approve_professional(self):
        response = self.app.post('/admin/approve-professional/1', headers={'Authorization': f'Bearer {self.user_token}'})
        self.assertEqual(response.status_code, 403)
        self.assertEqual(response.json, {"msg": "Admin access required"})

    def test_approve_non_existent_professional(self):
        response = self.app.post('/admin/approve-professional/999', headers={'Authorization': f'Bearer {self.admin_token}'})
        self.assertEqual(response.status_code, 404)

if __name__ == '__main__':
    unittest.main()