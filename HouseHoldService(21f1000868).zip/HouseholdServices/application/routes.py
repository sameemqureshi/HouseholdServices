from flask import Blueprint, request, jsonify,current_app as app, send_file,send_from_directory,url_for
from flask_jwt_extended import create_access_token,create_refresh_token, jwt_required
from sqlalchemy.exc import IntegrityError
from .models import *
from flask_jwt_extended import jwt_required, get_jwt_identity
from werkzeug.utils import secure_filename
import os
from sqlalchemy import or_
from application.celery.tasks import create_csv,create_csv_service_requests
from celery.result import AsyncResult

auth_bp = Blueprint('auth', __name__)
cache=app.cache

@app.get('/celery')
def celery():
    task=create_csv.delay()
    return(task.id,200)
@app.get('/get-csv/<id>')
def getCSV(id):
    result = AsyncResult(id)

    if result.ready():
        print(result.result,'result')
        return send_file(f'./application/celery/user-data/{result.result}'), 200
    else:
        return {'message' : 'task not ready'}, 405
     

@app.get('/create-csv')
@jwt_required()
def createCSV():
    task=create_csv.delay()
    return {'task_id':task.id},200

@app.get('/create-csv-service-requests')
@jwt_required()
def create_CSV_Service_Requests():
    task=create_csv_service_requests.delay()
    return {'task_id':task.id},200

@auth_bp.route('/admin/login', methods=['POST'])
def admin_login():
    data = request.json
    user = User.query.filter_by(email=data['email']).first()
    
    if not user or not user.check_password(data['password']):
        return jsonify({"msg": "Invalid credentials"}), 401
    
    if user.role != 'admin':
        return jsonify({"msg": "Unauthorized, not an admin"}), 403
    
    access_token = create_access_token(identity=user.id)
    return jsonify(access_token=access_token,role=user.role), 200

# View All the Users
@auth_bp.route('/admin/users', methods=['GET'])
@jwt_required()
def view_users():
    current_user_id = get_jwt_identity()
    current_user = User.query.get(current_user_id)
    # Ensure that only admins can access this route
    if current_user.role != 'admin':
        return jsonify({"msg": "Unauthorized, only admins can view users"}), 403

    # Fetch all users except admins
    users = User.query.filter(User.role != 'admin').all()
    users_list = [{"id": u.id, "username": u.username, "email": u.email, "role": u.role} for u in users]

    return jsonify(users=users_list), 200


@auth_bp.route('/uploaded_documents/<path:filename>', methods=['GET'])
def serve_document(filename):
    try:
        # Normalize the filename by stripping the "uploaded_documents/" prefix if present
        if filename.startswith('uploaded_documents/'):
            filename = filename.replace('uploaded_documents/', '', 1)
        
        # Access UPLOAD_FOLDER from config
        upload_folder = app.config['UPLOAD_FOLDER']
        
        # Serve the file using send_from_directory
        return send_from_directory(upload_folder, filename, as_attachment=False)
    except FileNotFoundError:
        return jsonify({"msg": "File not found"}), 404



@auth_bp.route('/admin/professionals', methods=['GET'])
@jwt_required()
def view_professionals():
    current_user_id = get_jwt_identity()
    current_user = User.query.get(current_user_id)
    # Ensure that only admins can access this route
    if current_user.role != 'admin':
        return jsonify({"msg": "Unauthorized, only admins can view professionals"}), 403

    # Fetch all professionals with approval_status 'pending'
    professionals = Professional.query.filter_by(approval_status='pending').all()
    professionals_list = []
    for p in professionals:
        # Normalize the document path by stripping the redundant "uploaded_documents/" prefix if present
        normalized_document = (
            p.documents.replace('uploaded_documents/', '', 1) if p.documents else None
        )
        
        # Construct the document URL
        document_url = (
            url_for('auth.serve_document', filename=normalized_document, _external=True)
            if normalized_document
            else None
        )

        professionals_list.append({
            "id": p.id,
            "username": p.username,
            "email": p.email,
            "role": 'Professional',
            "approval_status": p.approval_status,
            "experience_years": p.experience_years,
            "uploaded_document_url": document_url,  # Include document URL
            "service_name": p.service_name
        })

    return jsonify(professionals=professionals_list), 200


    
    # professionals_list = [{"id": p.id, "username": p.username, "email": p.email, "role": 'Professional', "approval_status": p.approval_status,"experience_years":p.experience_years,"uploaded_document":p.documents,"service_name":p.service_name} for p in professionals]

    # return jsonify(professionals=professionals_list), 200
# Get all Professional for the Table in admindashboard
@auth_bp.route('/admin/get-professionals', methods=['GET'])
@jwt_required()
def get_professionals():
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)

    # Ensure the user is an admin
    if user.role != 'admin':
        return jsonify({"msg": "Only admins can access this data"}), 403

    professionals = Professional.query.join(User, Professional.user_id == User.id).all()

    professionals_list = []
    for professional in professionals:
        professionals_list.append({
            'id': professional.id,
            'name': professional.username,
            'email': professional.email,
            'address': professional.address,
            'status': professional.approval_status
        })

    return jsonify(professionals=professionals_list), 200


@auth_bp.route('/admin/search-professionals', methods=['GET'])
@jwt_required()
def search_professionals():
    current_user_id = get_jwt_identity()
    
    user = User.query.get(current_user_id)

    # Ensure the user is an admin
    if user.role != 'admin':
        return jsonify({"msg": "Only admins can search professionals"}), 403

    search_query = request.args.get('query', '').lower()
    if not search_query:
        return jsonify({"msg": "Search query is required"}), 400

    professionals = Professional.query.join(User, Professional.user_id == User.id).filter(
        or_(
            User.username.ilike(f'%{search_query}%'),
            User.email.ilike(f'%{search_query}%'),
        )
    ).all()

    professionals_list = []
    for professional in professionals:
        professionals_list.append({
            'id': professional.id,
            'name': professional.username,
            'email': professional.email,
            'address': professional.address,
            'status': professional.approval_status
        })

    return jsonify(professionals=professionals_list), 200
@auth_bp.route('/admin/block-professional/<int:professional_id>', methods=['POST'])
@jwt_required()
def block_professional(professional_id):
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)

    # Ensure the user is an admin
    if user.role != 'admin':
        return jsonify({"msg": "Only admins can block professionals"}), 403

    professional = Professional.query.get_or_404(professional_id)
    professional.approval_status = 'blocked'
    db.session.commit()

    return jsonify({"msg": "Professional blocked successfully"}), 200

@auth_bp.route('/admin/unblock-professional/<int:professional_id>', methods=['POST'])
@jwt_required()
def unblock_professional(professional_id):
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)

    # Ensure the user is an admin
    if user.role != 'admin':
        return jsonify({"msg": "Only admins can unblock professionals"}), 403

    professional = Professional.query.get_or_404(professional_id)
    professional.approval_status = 'approved'
    db.session.commit()

    return jsonify({"msg": "Professional unblocked successfully"}), 200

@auth_bp.route('/admin/services', methods=['GET'])
@jwt_required()
def get_services():
    current_user_id = get_jwt_identity()
    current_user = User.query.get(current_user_id)

    # Ensure only admins can view services
    if current_user.role != 'admin':
        return jsonify({"msg": "Unauthorized, only admins can view services"}), 403

    services = Service.query.all()
    services_list = [{"id": s.id, "name": s.name, "description": s.description, "price": s.price, "time_required": s.time_required} for s in services]

    return jsonify(services=services_list), 200
# Create Services for Admin
@auth_bp.route('/admin/service', methods=['POST'])
@jwt_required()
def create_service():
    current_user_id = get_jwt_identity()
    current_user = User.query.get(current_user_id)

    # Ensure only admins can create a service
    if current_user.role != 'admin':
        return jsonify({"msg": "Unauthorized, only admins can create services"}), 403

    # Get data from request
    data = request.json
    new_service = Service(
        name=data['name'],
        description=data.get('description', ''),
        price=data['price'],
        time_required=data.get('time_required', 0)  # Default to 0 if not provided
    )
    db.session.add(new_service)
    db.session.commit()

    return jsonify({"msg": "Service created successfully", "service_id": new_service.id}), 201

# Update a Service
@auth_bp.route('/admin/service/update/<int:service_id>', methods=['PUT'])
@jwt_required()
def update_service(service_id):
    current_user_id = get_jwt_identity()
    current_user = User.query.get(current_user_id)

    # Ensure only admins can update a service
    if current_user.role != 'admin':
        return jsonify({"msg": "Unauthorized, only admins can update services"}), 403

    # Find the service to update
    service = Service.query.get(service_id)
    if not service:
        return jsonify({"msg": "Service not found"}), 404

    # Get data from request and update the fields
    data = request.json
    service.name = data.get('name', service.name)
    service.price = data.get('price', service.price)
    service.time_required = data.get('time_required', service.time_required)
    service.description = data.get('description', service.description)

    db.session.commit()

    return jsonify({"msg": "Service updated successfully"}), 200

# Delete a service
@auth_bp.route('/admin/service/delete/<int:service_id>', methods=['DELETE'])
@jwt_required()
def delete_service(service_id):
    current_user_id = get_jwt_identity()
    current_user = User.query.get(current_user_id)

    # Ensure only admins can delete a service
    if current_user.role != 'admin':
        return jsonify({"msg": "Unauthorized, only admins can delete services"}), 403

    # Find the service to delete
    service = Service.query.get(service_id)
    if not service:
        return jsonify({"msg": "Service not found"}), 404

    db.session.delete(service)
    db.session.commit()

    return jsonify({"msg": "Service deleted successfully"}), 200


@auth_bp.route('/admin/approve-professional/<int:id>', methods=['POST'])
@jwt_required()
def approve_professional(id):
    current_user = get_jwt_identity()  # This returns the identity of the logged-in user, typically the user_id
    user = User.query.filter_by(id=current_user).first()
    
    # Check if the user has the admin role
    if user.role != 'admin':
        return jsonify({"msg": "Admin access required"}), 403

    professional = Professional.query.get_or_404(id)

    # Mark the professional as approved
    professional.approval_status = 'approved'
    db.session.commit()
    
    return jsonify({"msg": "Professional approved successfully"}), 200


@auth_bp.route('/admin/reject-professional/<int:id>', methods=['POST'])
@jwt_required()
def reject_professional(id):
    current_user = get_jwt_identity()  # Get the current user's identity
    user = User.query.filter_by(id=current_user).first()

    # Check if the user has the admin role
    if user.role != 'admin':
        return jsonify({"msg": "Admin access required"}), 403

    professional = Professional.query.get_or_404(id)

    # Mark the professional as rejected
    professional.approval_status = 'rejected'
    db.session.commit()
    
    return jsonify({"msg": "Professional rejected successfully"}), 200




# Register user and Professional
@auth_bp.route('/register-user', methods=['POST'])
def register():
    data = request.json

    new_user = User(
            username=data['username'],
            email=data['email'],
            role='User',
            date_created=datetime.now()  # Assuming you have a date_created field
        )
    new_user.set_password(data['password'])

    db.session.add(new_user)
    db.session.commit()

    return jsonify({"msg": "User registered successfully"}), 201
    

from flask import request, jsonify
from werkzeug.utils import secure_filename
import os

UPLOAD_FOLDER = 'uploaded_documents'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

@auth_bp.route('/register-professional', methods=['POST'])
def register_professional():
    try:
        # Retrieve form fields
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        fullname = request.form.get('fullname')
        service_name = request.form.get('service_name')
        experience_years = request.form.get('experience_years')
        address = request.form.get('address')
        pin_code = request.form.get('pin_code')
        # existing_user=User.query.get()
        # Handle the document upload
        document = request.files.get('document')

        if document:
            filename = secure_filename(document.filename)
            document_path = os.path.join(UPLOAD_FOLDER, filename)
            document.save(document_path)
        else:
            document_path = None  # No file was uploaded

        # Create the professional in the database
        
        new_user = User(
            username=username,
            email=email,
            role='Professional',
            date_created=datetime.now()
        )
        new_user.set_password(password)
        db.session.add(new_user)
        db.session.commit()

        new_professional = Professional(
            user_id=new_user.id,
            username=username,
            email=email,
            password_hash=new_user.password_hash,
            fullname=fullname,
            service_name=service_name,
            experience_years=int(experience_years),
            documents=document_path,  # Save the document path
            address=address,
            pin_code=pin_code
        )
        db.session.add(new_professional)
        db.session.commit()
        
        return jsonify({"msg": "Professional registered successfully"}), 201
    # except IntegrityError as e:
    #     db.session.rollback()
    #     if 'UNIQUE constraint failed: users.email' in str(e):
    #         return jsonify({"msg": "Email already taken"}), 400
    #     elif 'UNIQUE constraint failed: users.username' in str(e):
    #         return jsonify({"msg": "Username already taken"}), 400
    #     else:
    #         return jsonify({"msg": "Database error"}), 500


    except Exception as e:
        return jsonify({"error": str(e)}), 500

# User Login
@auth_bp.route('/login-user', methods=['POST'])
def login():
    # Get the email and password from the request body
    data = request.get_json()

    email = data.get('email')
    password = data.get('password')

    # Find the user in the database
    user = User.query.filter_by(email=email).first()

    if user and user.check_password(password):
        # Generate access token and refresh token
        access_token = create_access_token(identity=user.id)
        refresh_token = create_refresh_token(identity=user.id)

        return jsonify({
            "access_token": access_token,
            "refresh_token": refresh_token,
            "role": user.role,
            "user_id": user.id
        }), 200

    else:
        # Return an error response if credentials are invalid
        return jsonify({"msg": "Invalid email or password"}), 401
    

# Service Request
@auth_bp.route('/admin/service-requests', methods=['GET'])
@jwt_required()
@cache.cached(timeout=5)
def view_all_service_requests():
    current_user_id = get_jwt_identity()
    current_user = User.query.get(current_user_id)

    # Ensure only admins can view service requests
    if current_user.role != 'admin':
        return jsonify({"msg": "Unauthorized, only admins can view service requests"}), 403

    service_requests = ServiceRequest.query.all()
    service_requests_list = []
    for request in service_requests:
        # Query the service name using service_id
        service_name = Service.query.get(request.service_id).name if request.service_id else None
        customer_name = User.query.get(request.customer_id).username
        professional=Professional.query.get(request.professional_id)
        professional_name = professional.username if professional else None
        
        # Append the request data along with service_name to the response list
        service_requests_list.append({
            'id': request.id,
            'service_id': request.service_id,
            'service_name': service_name,  # Add the service name here
            'customer_id': request.customer_id,
            'customer_name':customer_name,
            'professional_id': request.professional_id,
            'professional_name':professional_name,
            'date_of_request': request.date_of_request,
            'date_of_completion': request.date_of_completion,
            'status': request.status,
            'remarks': request.remarks
        })

    return jsonify(service_requests=service_requests_list), 200




@auth_bp.route('/user/service-request', methods=['GET'])
@jwt_required()
def get_service_requests():
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    if user.role != 'User':
        return jsonify({"msg": "Only customers can view their service requests"}), 403
    
    service_requests = ServiceRequest.query.filter_by(customer_id=current_user_id).all()
    service_requests_list = []
    for request in service_requests:
        service = Service.query.get(request.service_id)
        service_name = service.name if service else None
        professional=Professional.query.get(request.professional_id)
        professional_name=professional.username if professional else None
        service_requests_list.append({
            'id': request.id,
            'service_id': request.service_id,
            'service_name': service_name,
            'customer_id': request.customer_id,
            'professional_name': professional_name,
            'date_requested': request.date_of_request,
            'date_of_completion': request.date_of_completion,
            'status': request.status,
            'remarks': request.remarks
        })
    return jsonify(service_requests=service_requests_list), 200


@auth_bp.route('/user/service-request', methods=['POST'])
@jwt_required()
def create_service_request():
    current_user_id = get_jwt_identity()
    customer = User.query.get(current_user_id)

    # Ensure the user is a customer
    if customer.role != 'User':
        return jsonify({"msg": "Only customers can create service requests"}), 403
    # if data['service_id'] not in [service.id for service in Service.query.all()]:
    #     return jsonify({"msg": "Service id not found"}), 404
    # Get the data from the request
    data = request.get_json()

    # if data['service_id'] not in [service.id for service in Service.query.all()]:
    #     return jsonify({"msg": "Service id not found"}), 404
    # Create the service request
    new_request = ServiceRequest(
        service_id=data['service_id'],
        customer_id=current_user_id,
        remarks=data.get('remarks'),
        professional_id=data['professional_id'],
        date_of_request=datetime.strptime(data.get('date_of_request'), '%Y-%m-%d %H:%M:%S') if data.get('date_of_request') else datetime.now()
    )

    db.session.add(new_request)
    db.session.commit()

    return jsonify({"msg": "Service request created successfully", "service_request_id": new_request.id}), 201

@auth_bp.route('/user/service-request/<int:request_id>', methods=['PUT'])
@jwt_required()
def edit_service_request(request_id):
    current_user_id = get_jwt_identity()
    service_request = ServiceRequest.query.get_or_404(request_id)

    # Ensure the request belongs to the current customer
    if service_request.customer_id != current_user_id:
        return jsonify({"msg": "You can only edit your own service requests"}), 403

    # Get the updated data from the request
    data = request.get_json()

    # Update the fields if provided
    service_request.date_of_request = datetime.strptime(data.get('date_of_request'), '%Y-%m-%d %H:%M:%S') if data.get('date_of_request') else service_request.date_of_request
    service_request.remarks = data.get('remarks', service_request.remarks)
    service_request.status = data.get('status', service_request.status)

    db.session.commit()

    return jsonify({"msg": "Service request updated successfully"}), 200

@auth_bp.route('/user/service-request/close/<int:request_id>', methods=['POST'])
@jwt_required()
def close_service_request(request_id):
    current_user_id = get_jwt_identity()
    service_request = ServiceRequest.query.get_or_404(request_id)
    data = request.get_json()
    rating = data.get('rating')
    # Ensure the request belongs to the customer or allow an admin to close it
    if (service_request.customer_id != current_user_id and 
        service_request.professional_id !=Professional.query.filter_by(id=current_user_id).first().id and 
        User.query.get(current_user_id).role != 'admin'):
        return jsonify({"msg": "You can only close your own requests or be an admin"}), 403
    if rating is not None:
        try:
            rating = float(rating)  # Ensure rating is a float
        except ValueError:
            return jsonify({"msg": "Invalid rating value"}), 400

        service_request.rating = rating
        professional = Professional.query.get(service_request.professional_id)
        
        if professional:
            total_rating = professional.average_rating * professional.rating_count
            professional.rating_count += 1
            professional.average_rating = (total_rating + rating) / professional.rating_count
        else:
            return jsonify({"msg": "Professional not found"}), 404

    service_request.status = 'completed'
    service_request.date_of_completion = datetime.now()

    db.session.commit()

    return jsonify({"msg": "Service request closed successfully"}), 200


@auth_bp.route('/professional/service-request/close/<int:request_id>', methods=['POST'])
@jwt_required()
def professional_close_service_request(request_id):
    current_user_id = get_jwt_identity()
    professional_id=Professional.query.filter_by(user_id=current_user_id).first().id
    service_request = ServiceRequest.query.get_or_404(request_id)
    data = request.get_json()
    print (data)
    
    # Ensure the request belongs to the professional
    if service_request.professional_id != professional_id:
        return jsonify({"msg": "You can only close your own requests"}), 403
    
    # if rating is not None:
    #     try:
    #         rating = float(rating)  # Ensure rating is a float
    #     except ValueError:
    #         return jsonify({"msg": "Invalid rating value"}), 400

        # service_request.rating = rating
        # professional = Professional.query.get(service_request.professional_id)
        
        # if professional:
        #     total_rating = professional.average_rating * professional.rating_count
        #     professional.rating_count += 1
        #     professional.average_rating = (total_rating + rating) / professional.rating_count
        # else:
        #     return jsonify({"msg": "Professional not found"}), 404

    service_request.status = 'completed'
    service_request.date_of_completion = datetime.now()

    db.session.commit()

    return jsonify({"msg": "Service request closed successfully"}), 200
# Endpoints for Professionals
@auth_bp.route('/public/service/<int:service_id>/professionals', methods=['GET'])
@jwt_required()
@cache.memoize(timeout=5)
def get_professionals_for_service(service_id):
    service_name=Service.query.get(service_id).name
    professionals = Professional.query.filter_by(service_name=service_name, approval_status='approved').all()
    professionals_list = [{"id": p.id, "username": p.username, "email": p.email, "experience_years": p.experience_years, "address": p.address, "documents": p.documents,"rating":int(p.average_rating) } for p in professionals]

    return jsonify(professionals=professionals_list), 200

# Endpoints for Professionals
@auth_bp.route('/public/service/<int:service_id>/search-professionals', methods=['GET'])
@jwt_required()
@cache.memoize(timeout=5)
def search_professionals_user(service_id):
    service_name = Service.query.get(service_id).name
    search_query = request.args.get('query', '').lower()

    query = Professional.query.filter_by(service_name=service_name, approval_status='approved')

    if search_query:
        query = query.filter(
            (Professional.username.ilike(f'%{search_query}%')) |
            (Professional.email.ilike(f'%{search_query}%'))  |
            (Professional.address.ilike(f'%{search_query}%'))
        )

    professionals = query.all()
    professionals_list = [{"id": p.id, "username": p.username, "email": p.email, "experience_years": p.experience_years,"address":p.address, "documents": p.documents} for p in professionals]

    return jsonify(professionals=professionals_list), 200


from flask_jwt_extended import get_jwt_identity
from sqlalchemy import or_

@auth_bp.route('/professional/available-requests', methods=['GET'])
@jwt_required()
def get_available_requests():
    current_user_id = get_jwt_identity()
    
    professional_id=Professional.query.filter_by(user_id=current_user_id).first().id
    
    available_requests = ServiceRequest.query.filter(
        ServiceRequest.professional_id == professional_id,
        or_(ServiceRequest.status == 'requested')
    ).all()
    available_requests = [request.to_dict() for request in available_requests]
    # available_requests = ServiceRequest.query.filter(or_(ServiceRequest.status == 'assigned', ServiceRequest.status == 'requested')).all()
    # Prepare the response data
    response_data = []
    for request in available_requests:
        print('3',request)
        service = Service.query.get(request['service_id'])
        customer = User.query.get(request['customer_id'])
        
        request_data = request
        request_data['service_name'] = service.name if service else None
        request_data['customer_name'] = customer.username if customer else None
        
        response_data.append(request_data)

    return jsonify(response_data), 200

@auth_bp.route('/professional/rejected-requests', methods=['GET'])
@jwt_required()
def get_rejected_requests():
    current_user_id = get_jwt_identity()
    
    professional_id=Professional.query.filter_by(user_id=current_user_id).first().id
    
    available_requests = ServiceRequest.query.filter(
        ServiceRequest.professional_id == professional_id,
        or_(ServiceRequest.status == 'rejected')
    ).all()
    available_requests = [request.to_dict() for request in available_requests]
    # available_requests = ServiceRequest.query.filter(or_(ServiceRequest.status == 'assigned', ServiceRequest.status == 'requested')).all()
    # Prepare the response data
    response_data = []
    for request in available_requests:
        print('3',request)
        service = Service.query.get(request['service_id'])
        customer = User.query.get(request['customer_id'])
        
        request_data = request
        request_data['service_name'] = service.name if service else None
        request_data['customer_name'] = customer.username if customer else None
        
        response_data.append(request_data)

    return jsonify(response_data), 200

    # available_requests = ServiceRequest.query.filter_by(status='requested', professional_id=None).all()
@auth_bp.route('/professional/accept-request/<int:request_id>', methods=['POST'])
@jwt_required()
def accept_service_request(request_id):
    current_user_id = get_jwt_identity()
    
    professional=Professional.query.filter_by(user_id=current_user_id).first()
    # professional = User.query.get(current_user_id)
    user = User.query.get(current_user_id)
    # Ensure the user is a professional
    if user.role != 'Professional':
        return jsonify({"msg": "Only professionals can accept requests"}), 403

    # Find the service request
    service_request = ServiceRequest.query.get_or_404(request_id)
    # Example: Check if the request is still valid
    if service_request.status != 'requested':
        return jsonify({"msg": "This request cannot be accepted"}), 400


    # Check if the request has already been accepted by another professional
    # if service_request.professional_id is not None:
    #     return jsonify({"msg": "This request has already been accepted by another professional"}), 400

    # Assign the professional to the service request
    service_request.professional_id = professional.id
    service_request.status = 'assigned'
    db.session.commit()

    return jsonify({"msg": "Service request accepted successfully", "service_request_id": service_request.id}), 200

@auth_bp.route('/professional/reject-request/<int:request_id>', methods=['POST'])
@jwt_required()
def reject_service_request(request_id):
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    if user.role != 'Professional':
        return jsonify({"msg": "Only professionals can reject requests"}), 403
    professional=Professional.query.filter_by(user_id=current_user_id).first()

    # Ensure the user is a professional
    
    service_request = ServiceRequest.query.get_or_404(request_id)
    service_request.professional_id = professional.id
    service_request.status = 'rejected'
    db.session.commit()

    # The professional can reject the request without modifying the request itself.
    # This could also involve notifying the customer or tracking the rejection.

    return jsonify({"msg": "Service request rejected successfully"}), 200







@auth_bp.route('/professional/assigned-requests', methods=['GET'])
@jwt_required()
def view_assigned_requests():
    current_user_id = get_jwt_identity()
    
    user = User.query.get(current_user_id)
    professional = Professional.query.filter_by(user_id=current_user_id).first()
    print(current_user_id)
    print (professional.username)
    print(professional.id)

    # Ensure the user is a professional
    if user.role != 'Professional':
        return jsonify({"msg": "Only professionals can view assigned requests"}), 403

    # Get the service requests assigned to the professional
    assigned_requests = ServiceRequest.query.filter_by(professional_id=professional.id, status='assigned').all()
    assigned_requests_list = []
    for request in assigned_requests:
        service_name = Service.query.get(request.service_id).name if request.service_id else None
        customer_name = User.query.get(request.customer_id).username
        assigned_requests_list.append({
            'id': request.id,
            'service_id': request.service_id,
            'service_name': service_name,
            'customer_id': request.customer_id,
            'customer_name': customer_name,
            'professional_id': request.professional_id,
            'date_of_request': request.date_of_request,
            'date_of_completion': request.date_of_completion,
            'status': request.status,
            'remarks': request.remarks,
            'rating': request.rating
        })
    return jsonify(assigned_requests=assigned_requests_list), 200

@auth_bp.route('/professional/closed-requests', methods=['GET'])
@jwt_required()
def view_closed_requests():
    current_user_id = get_jwt_identity()
    professional_id=Professional
    user = User.query.get(current_user_id)
    professional = Professional.query.filter_by(user_id=current_user_id).first()
    print(current_user_id)
    print (professional.username)
    print(professional.id)

    # Ensure the user is a professional
    if user.role != 'Professional':
        return jsonify({"msg": "Only professionals can view closed requests"}), 403

    # Get the closed service requests assigned to the professional
    closed_requests = ServiceRequest.query.filter_by(professional_id=professional.id, status='completed').all()

    closed_requests_list = []
    for request in closed_requests:
        service_name = Service.query.get(request.service_id).name if request.service_id else None
        customer_name = User.query.get(request.customer_id).username
        closed_requests_list.append({
            'id': request.id,
            'service_id': request.service_id,
            'service_name': service_name,
            'customer_id': request.customer_id,
            'customer_name': customer_name,
            'professional_id': request.professional_id,
            'date_of_request': request.date_of_request,
            'date_of_completion': request.date_of_completion,
            'status': request.status,
            'remarks': request.remarks,
            'rating': request.rating
        })

    return jsonify(closed_requests=closed_requests_list), 200

@auth_bp.route('/public/services', methods=['GET'])
# @jwt_required()
@cache.cached(timeout=5)

def get_public_services():
    services = Service.query.all()
    services_list = [{"id": s.id, "name": s.name, "description": s.description, "price": s.price, "time_required": s.time_required} for s in services]

    return jsonify(services=services_list), 200


@auth_bp.route('/public/search-services', methods=['GET'])
# @jwt_required()
# @cache.cached(timeout=5)

def search_public_services():
    search_query = request.args.get('query', '')
    if not search_query:
        return jsonify({"msg": "Search query is required"}), 400

    services = Service.query.filter(
        (Service.name.ilike(f'%{search_query}%')) |
        (Service.description.ilike(f'%{search_query}%'))
    ).all()
    print(services)

    services_list = [{"id": s.id, "name": s.name, "description": s.description, "price": s.price, "time_required": s.time_required} for s in services]

    return jsonify(services=services_list), 200


    



