from celery import shared_task
from application.models import *
import flask_excel
from application.celery.mail_service import send_email
@shared_task(bind = True, ignore_result = False)
def create_csv(self):
    resource=User.query.all()
    column_names=[column.name for column in User.__table__.columns]
    print('col',column_names)
    csv_out=flask_excel.make_response_from_query_sets(resource,column_names=column_names,file_type='csv')
    with open('./application/celery/user-data/users.csv','wb') as file:
        file.write(csv_out.data)

    return 'users.csv'

@shared_task(bind = True, ignore_result = False)
def create_csv_service_requests(self):
    resource = ServiceRequest.query.filter_by(status='completed').all()
    print(resource)
    column_names=[column.name for column in ServiceRequest.__table__.columns]
    print(column_names)
    csv_out=flask_excel.make_response_from_query_sets(resource,column_names=column_names,file_type='csv')
    with open('./application/celery/user-data/service-requests.csv','wb') as file:
        file.write(csv_out.data)

    return 'service-requests.csv'

@shared_task(ignore_result=True)
def email_reminder(to,subject,content):
    send_email(to,subject,content )
         



    