from flask import current_app as app
from celery.schedules import crontab
from  application.celery.tasks import email_reminder
from application.models import Professional,ServiceRequest,User,Service
from sqlalchemy import or_
from app import db

celery_app = app.extensions["celery"]

@celery_app.on_after_configure.connect
def setup_periodic_tasks(sender, **kwargs):
     sender.add_periodic_task(
        crontab(hour=2,minute=40),  # Interval in seconds
        send_professional_reminder.s(),  # The task function
        name='Send Professional Reminder Every Day'
    )
     sender.add_periodic_task(
        crontab(day_of_month=26,hour=2,minute=40),  # Interval in seconds
        send_user_monthly_mail.s(),  # The task function
        name='Send User Reminder Every Month'
    )
    
  
    #   sender.add_periodic_task(crontab(day_of_week='monday'),email_reminder.s('professionals@gmail.com','Service Requests Reminder','<h1>Complete Assigned Requests'),name='Daily Reminder to Professionals')
    
    #  sender.add_periodic_task(5.0,email_reminder.s('sameemq@gmail.com','For Professionals','<h1>email_content</h1>'),name='Service Requests Reminder to Professionals')
    
    
      
     
@celery_app.task
def send_professional_reminder():
    professionals = Professional.query.all()

    for professional in professionals:
        professional_email = professional.email if professional else "default.professional@email.com"

        available_requests = (
            ServiceRequest.query
            .join(User, User.id == ServiceRequest.customer_id)
            .join(Service, Service.id == ServiceRequest.service_id)
            .filter(
                ServiceRequest.professional_id == professional.id,
                ServiceRequest.status != 'completed'
            )
            .all()
        )

        # Generate email content based on available requests
        requests_list = ''.join([
            f'<tr>'
            f'<td>{req.id}</td>'
            f'<td>{req.service.name}</td>'
            f'<td>{req.customer.username}</td>'  # Customer username from User table
            f'<td>{req.date_of_request}</td>'
            f'</tr>'
            for req in available_requests
        ])

        email_content = f"""
        <html><head><style>
            body{{font-family:Arial,sans-serif;margin:0;padding:0;background:#f4f4f4;}}
            .container{{width:600px;margin:20px auto;background:#fff;padding:20px;border-radius:8px;box-shadow:0 2px 5px rgba(0,0,0,.1);}}
            h1{{color:#333;text-align:center;}}
            table{{width:100%;border-collapse:collapse;margin-top:20px;}}
            th,td{{text-align:left;padding:12px;font-size:14px;color:#555;}}
            th{{background:#f1f1f1;}}
            tr:nth-child(even){{background:#f9f9f9;}}
            .footer{{text-align:center;margin-top:30px;font-size:14px;color:#777;}}
        </style></head><body>
        <div class="container">
            <h1>Assigned Service Requests Reminder</h1>
            <p>Dear {professional.fullname},</p>
            <p>Below is the list of service requests currently assigned to you:</p>
            <table>
                <thead><tr><th>Service ID</th><th>Service Name</th><th>Customer</th><th>Date of Request</th></tr></thead>
                <tbody>{requests_list}</tbody>
            </table>
            <p>If you have any questions, feel free to reach out.</p>
            <p>Thank you for your continued service!</p>
            <div class="footer">Best regards,<br> FixItPro Management Team ©</div>
        </div></body></html>
        """

        email_reminder(professional_email, ' Service Requests Reminder', email_content)

@celery_app.task
def send_user_monthly_mail():
    users=User.query.filter_by(role='User').all()
    for user in users:
        user_email = user.email if user else "default@email.com"
        user_requests = (
            ServiceRequest.query
            .join(Service, Service.id == ServiceRequest.service_id)
            .join(User, User.id == ServiceRequest.customer_id)
            .join(Professional, Professional.id == ServiceRequest.professional_id)
            .filter(ServiceRequest.customer_id == user.id)
            .all()
        )
        total_requests = len(user_requests)
        completed_requests = len([req for req in user_requests if req.status == 'completed'])
        
        requests_list = ''.join([
            f'<tr>'
            
            f'<td>{req.service.name}</td>' 
            f'<td>{Professional.query.get(req.professional_id).fullname if req.professional_id else "N/A"}</td>'  # Query to get professional's fullname
          # Customer username from User table
            f'<td>{req.date_of_request}</td>'
            f'<td>{req.rating if req.status == "completed" else "N/A"}</td>'
            f'</tr>'
            for req in user_requests
        ])

        email_content = f"""
        <html><head><style>
            body{{font-family:Arial,sans-serif;margin:0;padding:0;background:#f4f4f4;}}
            .container{{width:600px;margin:20px auto;background:#fff;padding:20px;border-radius:8px;box-shadow:0 2px 5px rgba(0,0,0,.1);}}
            h1{{color:#333;text-align:center;}}
            table{{width:100%;border-collapse:collapse;margin-top:20px;}}
            th,td{{text-align:left;padding:12px;font-size:14px;color:#555;}}
            th{{background:#f1f1f1;}}
            tr:nth-child(even){{background:#f9f9f9;}}
            .footer{{text-align:center;margin-top:30px;font-size:14px;color:#777;}}
        </style></head><body>
        <div class="container">
            <h1>Summary of this Month</h1>
            <p>Dear {user.username},</p>
            <p>This is the Monthly Summary of your Service Requests:</p>
            <p>Total Requests: <strong>{total_requests}</strong></p>
            <p>Completed Requests: <strong>{completed_requests}</strong></p>
           <table>
                
                <thead><tr><th>Service Name</th><th>Professional Name</th><th>Date of Request</th><th>Rating</th></tr></thead>
                <tbody>{requests_list}</tbody>
            </table>
            <p>If you have any questions, feel free to reach out.</p>
            <p>Thank you for your continued service!</p>
            <div class="footer">Best regards,<br> FixItPro Management Team ©</div>
        </div></body></html>
        """

        email_reminder(user_email, 'Summary of Your Orders', email_content)




@celery_app.task
def add(x, y):
    z = x + y
    print(z)