from app import db
from models import User

# Create a new admin user
admin_user = User(
    username="admin", 
    email="admin@example.com", 
    role="admin"
)
admin_user.set_password("adminpassword")  # Set a secure password

# Add to the database
db.session.add(admin_user)
db.session.commit()

print("Admin user created successfully!")
