from flask import Flask,render_template 
from application.models import db,User
from datetime import datetime, timedelta
from flask_jwt_extended import JWTManager
# from application.routes import auth_bp
from flask_caching import Cache
from application.celery.celery_worker import celery_init_app
import flask_excel as excel
# import os

app = Flask(__name__, static_folder='frontend')
app.config['CACHE_TYPE']="RedisCache"
app.config['CACHE_DEFAULT_TIMEOUT']=30
app.config['CACHE_REDIS_PORT']=6379
 
app.config['JWT_SECRET_KEY'] = 'a20ae81c59e2aa911352e4c2880b42a55347af2adf39d0c710561c94989d5a00'
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(days=1)
jwt = JWTManager(app)
cache=Cache(app)
app.cache=cache
# app.register_blueprint(auth_bp)

import os

# Ensure UPLOAD_FOLDER is an absolute path
UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploaded_documents')
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER


# celery_app=celery_init_app(app)

@app.route("/")
def hello_world():
    return render_template("index.html")

@app.get('/cache')
@cache.cached(timeout=5)
def cache():
    return f"time: {datetime.now()}", 200
# import application.celery.celery_schedule
excel.init_excel(app)
with app.app_context():
    # import application.celery.celery_schedule
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///HouseHoldServices.sqlite3'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    from application.routes import auth_bp
    app.register_blueprint(auth_bp)
    db.init_app(app)
    db.create_all()
    # admin_user = User(
    #     username="admin", 
    #     email="admin@example.com", 
    #     role="admin"
    #     )
    # admin_user.set_password("adminpassword")  # Set a secure password

    #     # Add to the database
    # db.session.add(admin_user)
    # db.session.commit()
    # db.session.commit()

    celery_app = celery_init_app(app)
    import application.celery.celery_schedule


if __name__=='__main__':
    
    # with app.app_context():
    #     app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///HouseHold.sqlite3'
    #     app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    #     from application.routes import auth_bp
    #     app.register_blueprint(auth_bp)
    #     db.init_app(app)
    #     # celery_app=celery_init_app(app)
    #     db.create_all()
        # admin_user = User(
        # username="admin", 
        # email="admin@example.com", 
        # role="admin"
        # )
        # admin_user.set_password("adminpassword")  # Set a secure password

        # # Add to the database
        # db.session.add(admin_user)
        # db.session.commit()

    #     celery_app=celery_init_app(app)
    #     # excel.init_excel(app)
        app.run(debug=True)
# celery_app=celery_init_app(app)
