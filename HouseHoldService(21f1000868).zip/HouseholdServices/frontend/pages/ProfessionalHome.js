import ServiceRequest from '../components/ServiceRequest.js';

export default {
  template: `
    <div class="container py-5">
      <h1>Welcome {{$store.state.role}} </h1>

      <!-- Available Requests -->
      <service-requests-component 
        :availableRequests="availableRequests" 
        @accept="acceptRequest"
        @reject="rejectRequest"
      />

      <!-- Ongoing Requests -->
      <br>
      <h2 class="h4 text-dark fw-bold"> <i class="bi bi-clipboard-data me-2"></i>Ongoing Requests</h2>
     
      <div v-if="assignedRequests.length > 0">
        <table class="table table-bordered table-hover">
          <thead>
            <tr>
              <th>Service Name</th>
              <th>Customer Name</th>
              <th>Date of Request</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="request in assignedRequests" :key="request.id">
              <td>{{ request.service_name }}</td>
              <td>{{ request.customer_name }}</td>
              <td>{{ request.date_of_request }}</td>
              <td>
                <button @click="closeRequest(request.id)" class="btn btn-danger btn-sm">Close</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div v-else>
        <p class="text-muted">No ongoing requests at the moment.</p>
      </div>

      <!-- Closed Requests -->
      <br>
      <h2 class="h4 text-dark fw-bold"> <i class="bi bi-clipboard-data me-2"></i>Closed Requests</h2>
     
      <div v-if="closedRequests.length > 0">
        <table class="table table-bordered table-hover">
          <thead>
            <tr>
              <th>Service Name</th>
              <th>Customer Name</th>
              <th>Date Requested</th>
              <th>Date Completed</th>
              <th>Rating</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="request in closedRequests" :key="request.id">
              <td>{{ request.service_name }}</td>
              <td>{{ request.customer_name }}</td>
              <td>{{ request.date_of_request }}</td>
              <td>{{ request.date_of_completion }}</td>
              <td>{{ request.rating }}</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div v-else>
        <p class="text-muted">No closed service requests.</p>
      </div>
    </div>
  `,

  data() {
    return {
      availableRequests: [],
      assignedRequests: [],
      closedRequests: [],
    };
  },

  components: {
    ServiceRequestsComponent: ServiceRequest,
  },

  methods: {
    async fetchServices() {
      try {
        const res = await fetch('http://127.0.0.1:5000/professional/available-requests', {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${this.$store.state.access_token}`,
          },
        });

        if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);

        const data = await res.json();
        console.log('Available Requests Data:', data);
        this.availableRequests = data || [];
      } catch (error) {
        console.error('Error fetching available requests:', error);
      }
    },

    async getAssignedRequests() {
      try {
        const res = await fetch('http://127.0.0.1:5000/professional/assigned-requests', {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${this.$store.state.access_token}`,
          },
        });

        if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);

        const data = await res.json();
        console.log('Assigned Requests Data:', data);
        this.assignedRequests = data.assigned_requests || [];
      } catch (error) {
        console.error('Error fetching assigned requests:', error);
      }
    },

    async getClosedRequests() {
      try {
        const res = await fetch('http://127.0.0.1:5000/professional/closed-requests', {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${this.$store.state.access_token}`,
          },
        });

        if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);

        const data = await res.json();
        console.log('Closed Requests Data:', data);
        this.closedRequests = data.closed_requests || [];
      } catch (error) {
        console.error('Error fetching closed requests:', error);
      }
    },

    async acceptRequest(requestId) {
      try {
        const res = await fetch(`http://127.0.0.1:5000/professional/accept-request/${requestId}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${this.$store.state.access_token}`,
          },
        });

        if (res.ok) {
          console.log(`Accepted request ID: ${requestId}`);
          alert('Request accepted successfully');
          this.updateRequests(requestId, 'accept');
        } else {
          const errorData = await res.json();
          console.error('Failed to accept request:', errorData);
          alert(`Failed to accept request: ${errorData.msg}`);
        }
      } catch (error) {
        console.error('Error accepting request:', error);
        alert('Error accepting request.');
      }
    },

    async rejectRequest(requestId) {
      try {
        const res = await fetch(`http://127.0.0.1:5000/professional/reject-request/${requestId}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${this.$store.state.access_token}`,
          },
        });

        if (res.ok) {
          console.log(`Rejected request ID: ${requestId}`);
          alert('Request rejected successfully');
          this.updateRequests(requestId, 'reject');
        } else {
          const errorData = await res.json();
          console.error('Failed to reject request:', errorData);
          alert(`Failed to reject request: ${errorData.msg}`);
        }
      } catch (error) {
        console.error('Error rejecting request:', error);
        alert('Error rejecting request.');
      }
    },

    async closeRequest(requestId) {
      try {
        console.log('Attempting to close request with ID:', requestId);
        const res = await fetch(`http://127.0.0.1:5000/professional/service-request/close/${requestId}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${this.$store.state.access_token}`,
          },
          body: JSON.stringify({}) // Ensure an empty JSON object is sent
        });

        if (res.ok) {
          console.log(`Closed request ID: ${requestId}`);
          alert('Request closed successfully');
          this.updateRequests(requestId, 'close');
        } else {
          const errorData = await res.json();
          console.error('Failed to close request:', errorData);
          alert(`Failed to close request: ${errorData.msg}`);
        }
      } catch (error) {
        console.error('Error closing request:', error);
        alert('Error closing request.');
      }
    },

    updateRequests(requestId, action) {
      if (action === 'accept') {
        const acceptedRequest = this.availableRequests.find(request => request.id === requestId);
        if (acceptedRequest) {
          this.assignedRequests.push(acceptedRequest);
          this.availableRequests = this.availableRequests.filter(request => request.id !== requestId);
        }
      } else if (action === 'reject') {
        this.availableRequests = this.availableRequests.filter(request => request.id !== requestId);
      } else if (action === 'close') {
        const closedRequest = this.assignedRequests.find(request => request.id === requestId);
        if (closedRequest) {
          closedRequest.status = 'completed';
          closedRequest.date_of_completion = new Date().toISOString();
          this.closedRequests.push(closedRequest);
          this.assignedRequests = this.assignedRequests.filter(request => request.id !== requestId);
        }
      }
      this.fetchServices(); // Fetch available requests again to update the list
    }
  },

  created() {
    this.fetchServices();
    this.getAssignedRequests();
    this.getClosedRequests();
  },
};