import ServiceCard from "../components/ServiceCard.js";
import ServiceRequest from "../components/ServiceRequest.js";
export default {
    template: `
  <div class="p-4">
         <div class="text-center mb-4">
            <h1>Services</h1>
        </div>
         <!-- Search Bar -->
    <div class="container mt-5">
      <!-- Search Bar -->
      <div>
        <div class="mb-3">
          <input
            type="text"
            class="form-control w-50"
            placeholder="Search Services"
            v-model="searchQuery"
            @input="searchServices"
          />
        </div>
        </div>

        <div class="row">
            <div class="col-md-4 mb-4" v-for="service in services" :key="service.id">
                <ServiceCard :id="service.id" :name="service.name" :description="service.description" :price="service.price" :time_required="service.time_required">
                </ServiceCard>
            </div>
        </div>
     
        <div v-if="serviceRequests.length > 0">
            <ServiceRequest :availableRequests="serviceRequests" :role="role" @complete="openCompleteModal"></ServiceRequest>
        </div>
        <div v-else>
            <p>No service requests found.</p>
        </div>

        <!-- Complete Service Request Modal -->
        <div class="modal fade" id="completeModal" tabindex="-1" aria-labelledby="completeModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="completeModalLabel">Complete Service Request</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <p><strong>Service Name:</strong> {{ selectedRequest?.service_name }}</p>
                        <p><strong>Professional Name:</strong> {{ selectedRequest?.professional_name }}</p>
                        <p><strong>Date Requested:</strong> {{ selectedRequest?.date_of_request }}</p>
                        <p><strong>Status:</strong> {{ selectedRequest?.status }}</p>
                        <div class="mb-3">
                            <label for="rating" class="form-label">Service Rating</label>
                            <input type="number" class="form-control" id="rating" v-model="rating" min="1" max="5" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" @click="handleComplete">Submit</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
      
 
     
    `,
    data() {
      return {
       searchQuery:'',
       services: [],
       serviceRequests:[],
       role:`${this.$store.state.role}`,
       selectedRequest: null,
       rating: 0
      }
    },
    methods: {
      openCompleteModal(requestId) {
          this.selectedRequest = this.serviceRequests.find(request => request.id === requestId);
          this.rating = 0; // Reset the rating
          const completeModal = new bootstrap.Modal(document.getElementById('completeModal'));
          completeModal.show();
      },
      async handleComplete() {
          if (!this.selectedRequest) return;

          console.log('Completed request with ID:', this.selectedRequest.id);
          const response = await fetch(`/user/service-request/close/${this.selectedRequest.id}`, {
              method: 'POST',
              headers: {
                  'Content-Type': 'application/json',
                  'Authorization': `Bearer ${this.$store.state.access_token}`
              },
              body: JSON.stringify({ rating: this.rating })
          });
          if (response.ok) {
              console.log("Service Request Closed");
              // Optionally, update the serviceRequests array to reflect the change
              this.serviceRequests = this.serviceRequests.filter(request => request.id !== this.selectedRequest.id);
              const completeModal = document.getElementById('completeModal');
            
                $('#completeModal').modal('hide')
            
          } else {
              console.error('Failed to complete service request');
          }
      },
      async searchServices() {
        console.log('Search query:', this.searchQuery);
        try {
          const res = await fetch(`http://127.0.0.1:5000/public/search-services?query=${this.searchQuery}`, {
            method: 'GET',
            headers: {
              'Authorization': `Bearer ${localStorage.getItem('access_token')}`
            }
          });
      
          if (!res.ok) {
            const errorText = await res.text();
            throw new Error(`HTTP error! status: ${res.status}, message: ${errorText}`);
          }
      
          const data = await res.json();
          this.services = data.services;
        } catch (error) {
          console.error('Error searching services:', error);
        }
      }
    },

    async mounted(){
        const response = await fetch('/public/services', {
            method: 'GET',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${this.$store.state.access_token}`
            }
          });
          if (response.ok) {
            console.log('Services fetched successfully');
            const data = await response.json();
            this.services = data.services;
            console.log('Services fetched successfully', this.services);
          } else {
            console.error('Failed to fetch services');
          }
          const serviceRequestsResponse = await fetch('/user/service-request', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${this.$store.state.access_token}`
            }
        });
        if (serviceRequestsResponse.ok) {
            console.log('Service requests fetched successfully');
            const serviceRequestsData = await serviceRequestsResponse.json();
            this.serviceRequests = serviceRequestsData.service_requests;
            console.log('Service requests fetched successfully', this.serviceRequests);
        } else {
            console.error('Failed to fetch service requests');
        }
    
    },
    components: {
        ServiceCard,
        ServiceRequest
    }
  }

  
