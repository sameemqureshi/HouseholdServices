export default {
    template: `
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card border-0" style="background: linear-gradient(145deg, #000000, #121212); color: #ffffff; border-radius: 16px; box-shadow: 0 20px 40px rgba(0,0,0,0.3);">
                <div class="card-header text-center" style="background: linear-gradient(145deg, #1a1a1a, #0a0a0a); color: #ffffff; border-bottom: 1px solid rgba(255,255,255,0.05); border-radius: 16px 16px 0 0; padding: 2rem;">
                    <h3 style="font-weight: 300; letter-spacing: 2px; text-transform: uppercase;">Register</h3>
                </div>
                <div class="card-body" style="padding: 2.5rem;">
                    <form @submit.prevent="register">
                        <div class="form-group mb-4">
                            <label for="username" style="color: #ffffff; font-size: 0.85rem; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 0.5rem;">Username</label>
                            <input type="text" class="form-control" id="username" placeholder="Enter username" v-model="username" required 
                                style="background-color: rgba(255,255,255,0.05); 
                                       color: #ffffff; 
                                       border: 1px solid rgba(255,255,255,0.1); 
                                       border-radius: 8px;
                                       padding: 0.8rem;
                                       transition: all 0.3s;
                                       backdrop-filter: blur(10px);"
                                onmouseover="this.style.borderColor='rgba(255,255,255,0.2)'"
                                onmouseout="this.style.borderColor='rgba(255,255,255,0.1)'">
                        </div>
                        <div class="form-group mb-4">
                            <label for="email" style="color: #ffffff; font-size: 0.85rem; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 0.5rem;">Email</label>
                            <input type="email" class="form-control" id="email" placeholder="Enter email" v-model="email" required 
                                style="background-color: rgba(255,255,255,0.05); 
                                       color: #ffffff; 
                                       border: 1px solid rgba(255,255,255,0.1); 
                                       border-radius: 8px;
                                       padding: 0.8rem;
                                       transition: all 0.3s;
                                       backdrop-filter: blur(10px);"
                                onmouseover="this.style.borderColor='rgba(255,255,255,0.2)'"
                                onmouseout="this.style.borderColor='rgba(255,255,255,0.1)'">
                        </div>
                          <div class="form-group mb-4">
                            <label for="password" style="color: #ffffff; font-size: 0.85rem; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 0.5rem;">Password</label>
                            <input type="password" class="form-control" id="password" placeholder="Enter password" v-model="password" required 
                                style="background-color: rgba(255,255,255,0.05); 
                                       color: #ffffff; 
                                       border: 1px solid rgba(255,255,255,0.1); 
                                       border-radius: 8px;
                                       padding: 0.8rem;
                                       transition: all 0.3s;
                                       backdrop-filter: blur(10px);"
                                onmouseover="this.style.borderColor='rgba(255,255,255,0.2)'"
                                onmouseout="this.style.borderColor='rgba(255,255,255,0.1)'">
                        </div>
                                    <div class="form-group mb-4">
                            <label for="role" style="color: #ffffff; font-size: 0.85rem; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 0.5rem;">Role</label>
                            <select class="form-control" id="role" v-model="role" required 
                                style="background-color: #121212; 
                                       color: #ffffff; 
                                       border: 1px solid rgba(255,255,255,0.1); 
                                       border-radius: 8px;
                                       padding: 1rem 0.8rem;
                                       transition: all 0.3s;
                                       width: 100%;
                                       height: auto;
                                       line-height: 1.5;
                                       box-shadow: 0 2px 4px rgba(0,0,0,0.2);
                                       cursor: pointer;
                                       text-overflow: ellipsis;
                                       white-space: nowrap;
                                       overflow: hidden;"
                                onmouseover="this.style.borderColor='rgba(255,255,255,0.2)'"
                                onmouseout="this.style.borderColor='rgba(255,255,255,0.1)'">
                                <option value="User" style="background-color: #121212; color: #ffffff; padding: 12px;">User</option>
                                <option value="Professional" style="background-color: #121212; color: #ffffff; padding: 12px;">Professional</option>
                            </select>
                        </div>
                        <div v-if="role === 'Professional'" style="border-top: 1px solid rgba(255,255,255,0.05); margin-top: 2rem; padding-top: 2rem;">
                            <div class="form-group mb-4">
                                <label for="fullname" style="color: #ffffff; font-size: 0.85rem; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 0.5rem;">Full Name</label>
                                <input type="text" class="form-control" id="fullname" placeholder="Enter full name" v-model="fullname" required 
                                    style="background-color: rgba(255,255,255,0.05); 
                                           color: #ffffff; 
                                           border: 1px solid rgba(255,255,255,0.1); 
                                           border-radius: 8px;
                                           padding: 0.8rem;
                                           transition: all 0.3s;
                                           backdrop-filter: blur(10px);"
                                    onmouseover="this.style.borderColor='rgba(255,255,255,0.2)'"
                                    onmouseout="this.style.borderColor='rgba(255,255,255,0.1)'">
                            </div>
                           <div class="form-group mb-4">
                            <label for="service_name" style="color: #ffffff; font-size: 0.85rem; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 0.5rem;">Service Name</label>
                            <select 
                            class="form-control" 
                            id="service_name" 
                            v-model="selectedService"
                            required 
                            style="background-color: rgba(255,255,255,0.05); 
                                    color: #ffffff; 
                                    border: 1px solid rgba(255,255,255,0.1); 
                                    border-radius: 8px;
                                    padding: 0.8rem;
                                    transition: all 0.3s;
                                    backdrop-filter: blur(10px);
                                    appearance: none;
                                    background-image: url('data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22292.4%22%20height%3D%22292.4%22%3E%3Cpath%20fill%3D%22%23FFFFFF%22%20d%3D%22M287%2069.4a17.6%2017.6%200%200%200-13-5.4H18.4c-5%200-9.3%201.8-12.9%205.4A17.6%2017.6%200%200%200%200%2082.2c0%205%201.8%209.3%205.4%2012.9l128%20127.9c3.6%203.6%207.8%205.4%2012.8%205.4s9.2-1.8%2012.8-5.4L287%2095c3.5-3.5%205.4-7.8%205.4-12.8%200-5-1.9-9.2-5.5-12.8z%22%2F%3E%3C%2Fsvg%3E');
                                    background-repeat: no-repeat;
                                    background-position: right 0.7em top 50%;
                                    background-size: 0.65em auto;"
                            @mouseover="$event.target.style.borderColor='rgba(255,255,255,0.2)'"
                            @mouseout="$event.target.style.borderColor='rgba(255,255,255,0.1)'"
                            >
                            
                            <option 
                                v-for="service in services" 
                                :key="service.id" 
                                :value="service"
                            >
                                {{ service.name }}
                            </option>
                            </select>
                            </div>

                            <div class="form-group mb-4">
                                <label for="experience_years" style="color: #ffffff; font-size: 0.85rem; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 0.5rem;">Experience Years</label>
                                <input type="number" class="form-control" id="experience_years" placeholder="Enter years of experience" v-model="experience_years" required 
                                    style="background-color: rgba(255,255,255,0.05); 
                                           color: #ffffff; 
                                           border: 1px solid rgba(255,255,255,0.1); 
                                           border-radius: 8px;
                                           padding: 0.8rem;
                                           transition: all 0.3s;
                                           backdrop-filter: blur(10px);"
                                    onmouseover="this.style.borderColor='rgba(255,255,255,0.2)'"
                                    onmouseout="this.style.borderColor='rgba(255,255,255,0.1)'">
                            </div>
                            <div class="form-group mb-4">
                                <label for="address" style="color: #ffffff; font-size: 0.85rem; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 0.5rem;">Address</label>
                                <input type="text" class="form-control" id="address" placeholder="Enter address" v-model="address" required 
                                    style="background-color: rgba(255,255,255,0.05); 
                                           color: #ffffff; 
                                           border: 1px solid rgba(255,255,255,0.1); 
                                           border-radius: 8px;
                                           padding: 0.8rem;
                                           transition: all 0.3s;
                                           backdrop-filter: blur(10px);"
                                    onmouseover="this.style.borderColor='rgba(255,255,255,0.2)'"
                                    onmouseout="this.style.borderColor='rgba(255,255,255,0.1)'">
                            </div>
                            <div class="form-group mb-4">
                                <label for="pin_code" style="color: #ffffff; font-size: 0.85rem; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 0.5rem;">Pin Code</label>
                                <input type="text" class="form-control" id="pin_code" placeholder="Enter pin code" v-model="pin_code" required 
                                    style="background-color: rgba(255,255,255,0.05); 
                                           color: #ffffff; 
                                           border: 1px solid rgba(255,255,255,0.1); 
                                           border-radius: 8px;
                                           padding: 0.8rem;
                                           transition: all 0.3s;
                                           backdrop-filter: blur(10px);"
                                    onmouseover="this.style.borderColor='rgba(255,255,255,0.2)'"
                                    onmouseout="this.style.borderColor='rgba(255,255,255,0.1)'">
                            </div>
                            <div class="form-group mb-4">
                                <label for="document" style="color: #ffffff; font-size: 0.85rem; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 0.5rem;">Document</label>
                                <input type="file" class="form-control-file" id="document" @change="handleFileUpload" 
                                    style="color: #ffffff;
                                           background-color: rgba(255,255,255,0.05);
                                           border: 1px solid rgba(255,255,255,0.1);
                                           border-radius: 8px;
                                           padding: 0.8rem;
                                           width: 100%;
                                           transition: all 0.3s;"
                                    onmouseover="this.style.borderColor='rgba(255,255,255,0.2)'"
                                    onmouseout="this.style.borderColor='rgba(255,255,255,0.1)'">
                            </div>
                        </div>
                        <button type="submit" class="btn btn-block" 
                            style="background: linear-gradient(145deg, #ffffff, #f5f5f5);
                                   color: #000000;
                                   border: none;
                                   border-radius: 8px;
                                   padding: 1rem;
                                   font-weight: 500;
                                   letter-spacing: 1px;
                                   text-transform: uppercase;
                                   transition: all 0.3s;
                                   margin-top: 2rem;
                                   box-shadow: 0 4px 6px rgba(0,0,0,0.1);"
                            onmouseover="this.style.transform='translateY(-2px)';this.style.boxShadow='0 6px 8px rgba(0,0,0,0.2)'"
                            onmouseout="this.style.transform='translateY(0)';this.style.boxShadow='0 4px 6px rgba(0,0,0,0.1)'">
                            Register
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>`,
    data() {
        return {
            username: '',
            email: '',
            password: '',
            role: 'User',
            fullname: '',
            // service_name: '',
            services:[],
            selectedService: { id: '', name: '' },
            experience_years: '',
            address: '',
            pin_code: '',
            document: null
        };
    },
    created() {
        this.fetchServices();
    },
    // computed: {
    //     displayedServiceName() {
    //       return this.selectedService.name || 'Select a service'
    //     }
    //   },
    methods: {
        handleFileUpload(event) {
            this.document = event.target.files[0];
        },
        async register() {
            if (this.role === 'Professional') {
                await this.registerProfessional();
            } else {
                await this.registerUser();
            }
        },
        async registerUser() {
            const url = 'http://127.0.0.1:5000/register-user';
            const payload = {
                username: this.username,
                email: this.email,
                password: this.password
            };

            const res = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify(payload)
            });

            if (res.ok) {
                const data = await res.json();
                alert('Registration Successful');
                this.$router.push('/login');

                console.log(data);
            } else {
                const errorData = await res.json();
                console.error(errorData);
            }
        },
        async registerProfessional() {
            const url = 'http://127.0.0.1:5000/register-professional';
            let formData = new FormData();
            formData.append('username', this.username);
            formData.append('email', this.email);
            formData.append('password', this.password);
            formData.append('fullname', this.fullname);
            formData.append('service_name', this.selectedService.name);
            formData.append('experience_years', this.experience_years);
            formData.append('address', this.address);
            formData.append('pin_code', this.pin_code);
            if (this.document) {
                formData.append('document', this.document);
            }

            const res = await fetch(url, {
                method: 'POST',
                body: formData
            });

            if (res.ok) {
                const data = await res.json();
                this.$router.push('/login');
                console.log(data);
            } else {
                const errorData = await res.json();
                alert(errorData)
                console.error(errorData);
            }
        },
        async fetchServices() {
            const response = await fetch('/public/services', {
                method: 'GET',
                headers: {
                  'Content-Type': 'application/json'
                }
              });
              if (response.ok) {
                console.log('Services fetched successfully');
                const data = await response.json();
                this.services = data.services;
              } else {
                console.error('Failed to fetch services');
              }
          }
        

    }
};