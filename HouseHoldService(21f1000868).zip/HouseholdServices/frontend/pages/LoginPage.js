export default {
    template: `
      <div class="container mt-5">
        <div class="row justify-content-center">
          <div class="col-md-5">
            <div class="card border-0" style="background: linear-gradient(145deg, #000000, #121212); color: #ffffff; border-radius: 16px; box-shadow: 0 20px 40px rgba(0,0,0,0.3);">
              <div class="card-header text-center" style="background: linear-gradient(145deg, #1a1a1a, #0a0a0a); color: #ffffff; border-bottom: 1px solid rgba(255,255,255,0.05); border-radius: 16px 16px 0 0; padding: 2rem;">
                <h3 style="font-weight: 300; letter-spacing: 2px; text-transform: uppercase;">Admin Login</h3>
              </div>
              <div class="card-body" style="padding: 2.5rem;">
                <form @submit.prevent="submitLogin">
                  <div class="form-group mb-4">
                    <label for="email" style="color: #ffffff; font-size: 0.85rem; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 0.5rem;">Email</label>
                    <input 
                      type="email" 
                      id="email"
                      class="form-control" 
                      placeholder="Enter your email"
                      v-model="email"
                      style="background-color: rgba(255,255,255,0.05); 
                             color: #ffffff; 
                             border: 1px solid rgba(255,255,255,0.1); 
                             border-radius: 8px;
                             padding: 0.8rem;
                             transition: all 0.3s;
                             backdrop-filter: blur(10px);
                             width: 100%;"
                      @mouseover="$event.target.style.borderColor='rgba(255,255,255,0.2)'"
                      @mouseout="$event.target.style.borderColor='rgba(255,255,255,0.1)'"
                      required
                    >
                  </div>
                  <div class="form-group mb-4">
                    <label for="password" style="color: #ffffff; font-size: 0.85rem; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 0.5rem;">Password</label>
                    <input 
                      type="password" 
                      id="password"
                      class="form-control" 
                      placeholder="Enter your password"
                      v-model="password"
                      style="background-color: rgba(255,255,255,0.05); 
                             color: #ffffff; 
                             border: 1px solid rgba(255,255,255,0.1); 
                             border-radius: 8px;
                             padding: 0.8rem;
                             transition: all 0.3s;
                             backdrop-filter: blur(10px);
                             width: 100%;"
                      @mouseover="$event.target.style.borderColor='rgba(255,255,255,0.2)'"
                      @mouseout="$event.target.style.borderColor='rgba(255,255,255,0.1)'"
                      required
                    >
                  </div>
                  <button 
                    type="submit" 
                    class="btn w-100" 
                    style="background: linear-gradient(145deg, #ffffff, #f5f5f5);
                           color: #000000;
                           border: none;
                           border-radius: 8px;
                           padding: 1rem;
                           font-weight: 500;
                           letter-spacing: 1px;
                           text-transform: uppercase;
                           transition: all 0.3s;
                           margin-top: 2rem;
                           box-shadow: 0 4px 6px rgba(0,0,0,0.1);"
                    @mouseover="$event.target.style.transform='translateY(-2px)';$event.target.style.boxShadow='0 6px 8px rgba(0,0,0,0.2)'"
                    @mouseout="$event.target.style.transform='translateY(0)';$event.target.style.boxShadow='0 4px 6px rgba(0,0,0,0.1)'"
                  >
                    Login
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    `,
    data() {
      return {
        email: '',
        password: ''
      }
    },
    methods: {
      async submitLogin() {
        try {
          const res = await fetch('http://127.0.0.1:5000/admin/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
              'email': this.email, 
              'password': this.password 
            })
          })
          
          if (res.ok) {
            const data = await res.json()
            console.log(data), localStorage.setItem('user', JSON.stringify(data))
            localStorage.setItem('access_token', data.access_token)
            this.$store.commit('setUser');
            this.$router.push('/admin-dashboard')
             // Redirect to AdminDashboard
            // Handle successful login here (e.g., store token, redirect, etc.)
          } else {
            // Handle login error here
            console.error('Login failed')
          }
        } catch (error) {
          console.error('Login error:', error)
        }
      }
    }
  }