export default {
  template: `
   <div class="container mt-5">

 <h1>Welcome Admin</h1>
   <div class="d-flex justify-content-end mb-4">
    
    <button @click="create_csv" class="btn btn-dark">Export Users as CSV</button>
  </div>
  <div class="container mt-5">

    <!-- Search Bar -->
    <div class="container mt-5">
      <!-- Search Bar -->
      <div>
        <div class="mb-3">
          <input
            type="text"
            class="form-control w-50"
            placeholder="Search professionals by name or email..."
            v-model="searchQuery"
            @input="searchProfessionals"
          />
        </div>

        <!-- Professional List -->
        <div class="table-responsive">
         <table class="table table-striped table-dark table-hover">
            <thead>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="professional in allProfessionals" :key="professional.id">
                <td>{{ professional.name }}</td>
                <td>{{ professional.email }}</td>
                <td>
                  <span
                    class="badge"
                    :class="{
                      'bg-success': professional.status === 'approved',
                      'bg-danger': professional.status === 'blocked',
                    }"
                  >
                    {{ professional.status }}
                  </span>
                </td>
                <td>
                  <button
                    v-if="professional.status === 'approved'"
                    class="btn btn-danger btn-sm"
                    @click="blockProfessional(professional.id)"
                  >
                    Block
                  </button>
                  <button
                    v-if="professional.status === 'blocked'"
                    class="btn btn-warning btn-sm"
                    @click="unblockProfessional(professional.id)"
                  >
                    Unblock
                  </button>
                  <button
                    v-if="professional.status === 'pending'"
                    class="btn btn-success btn-sm"
                    @click="approveProfessional(professional.id)"
                  >
                    Approve
                  </button>
                 
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <div class="services mt-5">
  <!-- Button to trigger modal with primary color -->
   <div class="text-center mb-4">
    <button
      type="button"
      class="btn btn-dark btn-lg px-5 py-3"
      data-toggle="modal"
      data-target="#createServiceModal"
      style="border-radius: 30px; transition: transform 0.3s ease-in-out; font-weight: bold; text-transform: uppercase;"
      onmouseover="this.style.transform='scale(1.05)'"
      onmouseout="this.style.transform='scale(1)'"
    >
      Create Service
    </button>
  
    <h2 class="text-center" style="color: #ffffff; font-weight: 300; text-transform: uppercase; letter-spacing: 1.5px; margin-bottom: 2rem;">
      All Services
    </h2>
    <div class="row">
      <div class="col-md-4" v-for="(service, index) in displayedServices" :key="service.id">
        <div class="card mb-4 shadow-sm" 
             style="background: linear-gradient(145deg, #1a1a1a, #0a0a0a); color: #ffffff; border-radius: 16px; box-shadow: 0 10px 20px rgba(0,0,0,0.3);">
          <div class="card-body">
            <h5 class="card-title" 
                style="font-weight: 400; text-transform: uppercase; letter-spacing: 1px; color: #f5f5f5;">
              {{ service.name }}
            </h5>
            <p class="card-text" 
               style="font-size: 0.85rem; color: rgba(255,255,255,0.8);">
               Description: {{ service.description }}
            </p>
            <p class="card-text" 
               style="font-size: 0.85rem; color: rgba(255,255,255,0.8);">
               Price: {{ service.price }}
            </p>
            <p class="card-text" 
               style="font-size: 0.85rem; color: rgba(255,255,255,0.8);">
               Time Required: {{ service.time_required }} hours
            </p>
            <button class="btn btn-warning btn-sm" 
                    style="color: #000; background: #ffbb33; border: none; border-radius: 8px; padding: 0.5rem 1rem; transition: transform 0.3s;"
                    onmouseover="this.style.transform='scale(1.05)'"
                    onmouseout="this.style.transform='scale(1)'"
                    @click="openEditModal(service)">
              Edit
            </button>
            <button class="btn btn-danger btn-sm" 
                    style="color: #ffffff; background: #d9534f; border: none; border-radius: 8px; padding: 0.5rem 1rem; transition: transform 0.3s;"
                    onmouseover="this.style.transform='scale(1.05)'"
                    onmouseout="this.style.transform='scale(1)'"
                    @click="deleteService(service.id)">
              Delete
            </button>
          </div>
        </div>
      </div>
    </div>
    <button v-if="services.length > servicesLimit" class="btn btn-link text-primary" @click="showAllServices">Show More</button>
  </div>
  </div>

  

  <!-- Create Service Modal with color customization -->
  <div class="modal fade" id="createServiceModal" tabindex="-1" aria-labelledby="createServiceModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <!-- Modal header with custom background color -->
        <div class="modal-header bg-primary text-white">
          <h5 class="modal-title" id="createServiceModalLabel">Create Service</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form @submit.prevent="createService">
            <div class="mb-3">
              <label for="serviceName" class="form-label">Service Name</label>
              <input type="text" class="form-control" id="serviceName" v-model="serviceName" required>
            </div>
            <div class="mb-3">
              <label for="serviceDescription" class="form-label">Service Description</label>
              <textarea class="form-control" id="serviceDescription" v-model="serviceDescription"></textarea>
            </div>
            <div class="mb-3">
              <label for="servicePrice" class="form-label">Service Price</label>
              <input type="number" class="form-control" id="servicePrice" v-model="servicePrice" required>
            </div>
            <div class="mb-3">
              <label for="serviceTimeRequired" class="form-label">Time Required (hours)</label>
              <input type="number" class="form-control" id="serviceTimeRequired" v-model="serviceTimeRequired">
            </div>
            <!-- Modal footer with button colors -->
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-success">Create Service</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
 


  <!-- Users Section with card styling and uniform colors -->
  <div class="users mt-5">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <div>
      <h2 class="text-dark mb-1">Professionals Awaiting Approval</h2>
      <p class="text-muted">Review and approve professionals to join our platform</p>
    </div>
  
      <div class="col-md-4 mb-4" v-for="(user, index) in displayedUsers" :key="user.id">
        <div class="card h-100" style="background: linear-gradient(145deg, #2a2a2a, #1a1a1a); color: #ffffff; border-radius: 16px; box-shadow: 0 10px 20px rgba(0,0,0,0.3); transition: all 0.3s ease;">
          <div class="card-body d-flex flex-column">
            <div class="text-center mb-3">
              <div class="avatar-placeholder mb-2" style="width: 80px; height: 80px; background-color: #007bff; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 2rem; font-weight: bold;">
                {{ user.username.charAt(0).toUpperCase() }}
              </div>
              <h5 class="card-title text-primary mb-0">{{ user.username }}</h5>
            </div>
            <p class="card-text text-muted mb-2"><i class="fas fa-envelope me-2"></i>{{ user.email }}</p>
            <p class="card-text text-muted mb-3"><i class="fas fa-user-tag me-2"></i>{{ user.role }}</p>
            <div class="mt-auto d-flex justify-content-between">
              <button class="btn btn-info btn-sm flex-grow-1 me-2" 
                style="border: none; border-radius: 8px; padding: 0.5rem 1rem; transition: all 0.3s ease;"
                @click="viewProfessional(user)">
                <i class="fas fa-eye me-2"></i>View
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <button v-if="users.length > usersLimit" class="btn btn-outline-primary mt-3" @click="showAllUsers">
      Show More <i class="fas fa-chevron-down ms-2"></i>
    </button>
  </div>

  <!-- Professional Details Modal -->
  <div class="modal fade" id="professionalModal" tabindex="-1" aria-labelledby="professionalModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content" style="background: linear-gradient(145deg, #2a2a2a, #1a1a1a); color: #ffffff; border-radius: 16px;">
        <div class="modal-header border-bottom-0">
          <h5 class="modal-title text-primary" id="professionalModalLabel">Professional Details</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div v-if="selectedProfessional">
            <div class="text-center mb-4">
              <div class="avatar-placeholder mb-3" style="width: 100px; height: 100px; background-color: #007bff; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 3rem; font-weight: bold;">
                {{ selectedProfessional.username.charAt(0).toUpperCase() }}
              </div>
              <h4 class="text-primary">{{ selectedProfessional.username }}</h4>
            </div>
            <p><strong>Email:</strong> {{ selectedProfessional.email }}</p>
            <p><strong>Role:</strong> {{ selectedProfessional.role }}</p>
            <p><strong>Document:</strong> <a :href="selectedProfessional.uploaded_document_url" target="_blank">View Document</a></p>
            <p><strong>Experience Years:</strong> {{ selectedProfessional.experience_years }}</p>
            <p><strong>Service:</strong> {{ selectedProfessional.service_name }}</p>
            <button class="btn btn-success btn-sm flex-grow-1 me-3" 
        style="border: none; border-radius: 8px; padding: 0.5rem 1rem; transition: all 0.3s ease;"
        @click="approveProfessional(selectedProfessional.id)">
        <i class="fas fa-check me-2"></i>Approve
      </button>
      <button class="btn btn-danger btn-sm flex-grow-1" 
              style="border: none; border-radius: 8px; padding: 0.5rem 1rem; transition: all 0.3s ease;"
              @click="rejectProfessional(selectedProfessional.id)">
        <i class="fas fa-times me-2"></i>Reject
      </button>
          </div>
        </div>
       
      </div>
    </div>
  </div>

  <!-- Edit Service Modal with color customization -->
  <div class="modal fade" id="editServiceModal" tabindex="-1" aria-labelledby="editServiceModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header bg-warning text-white">
          <h5 class="modal-title" id="editServiceModalLabel">Edit Service</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form @submit.prevent="updateService">
            <div class="mb-3">
              <label for="editServiceName" class="form-label">Service Name</label>
              <input type="text" class="form-control" id="editServiceName" v-model="editService.name" required>
            </div>
            <div class="mb-3">
              <label for="editServiceDescription" class="form-label">Service Description</label>
              <textarea class="form-control" id="editServiceDescription" v-model="editService.description"></textarea>
            </div>
            <div class="mb-3">
              <label for="editServicePrice" class="form-label">Service Price</label>
              <input type="number" class="form-control" id="editServicePrice" v-model="editService.price" required>
            </div>
            <div class="mb-3">
              <label for="editServiceTimeRequired" class="form-label">Time Required (hours)</label>
              <input type="number" class="form-control" id="editServiceTimeRequired" v-model="editService.time_required">
            </div>
            <!-- Modal footer with button colors -->
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-warning">Update Service</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  <!-- Service Requests Section -->
  <div v-if="serviceRequests.length > 0" class="table-responsive">
    <div class="d-flex justify-content-end mb-4">
    
    <button @click="create_service_requests_csv" class="btn btn-dark">Export Completed  Service Requests as CSV</button>
  </div>
    <table class="table table-hover table-bordered align-middle text-center">
      <thead class="bg-dark text-white">
        <tr>
          <th scope="col">Customer Name</th>
          <th scope="col">Service Name</th>
          <th scope="col">Status</th>
          <th scope="col">Completion Date</th>
          <th scope="col">Professional Name</th>
          <th scope="col">Requested Date</th>
        
        </tr>
      </thead>
      <tbody>
        <tr v-for="request in serviceRequests" :key="request.id" class="text-white" style="background-color: #2c3e50;">
          <td>{{ request.customer_name }}</td>
          <td>{{ request.service_name }}</td>
          <td>
            <span class="badge" :class="{
              'bg-success': request.status === 'Completed',
              'bg-warning text-dark': request.status === 'In Progress',
              'bg-info': request.status === 'Pending',
              'bg-danger': request.status === 'Cancelled'
            }">{{ request.status }}
            </span>
          </td>
          <td>{{ request.date_of_completion || 'Not completed' }}</td>
          <td>{{ request.professional_name }}</td>
          <td>{{ request.date_of_request }}</td>
         
        </tr>
      </tbody>
    </table>
  </div>
  <div v-else>
    <p class="text-center text-muted">No service requests found.</p>
  </div>
</div>

    `,
  data() {
    return {
      searchQuery:'',
      users: [],
      services: [],
      serviceName: '',
      serviceDescription: '',
      servicePrice: '',
      serviceTimeRequired: '',
      allProfessionals:[],
      selectedProfessional: null,
      filteredProfessionals: [],
      editService: {
        id: null,
        name: '',
        description: '',
        price: '',
        time_required: ''
      },
      servicesLimit: 3,
      usersLimit: 3,
      serviceRequests: [],
      isLoading: true,
      error: null
    }
  },
  computed: {
    displayedServices() {
      return this.services.slice(0, this.servicesLimit);
    },
    displayedUsers() {
      return this.users?.slice(0, this.usersLimit);
    }
  },
  methods: {
    async fetchUsers() {
      try {
        const res = await fetch('http://127.0.0.1:5000/admin/professionals', {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('access_token')}`
          }
        });
        if (res.ok) {
          const data = await res.json();
          this.users = data.professionals;
          console.log("see this", data.professionals);
        } else {
          console.error('Failed to fetch users');
        }
      } catch (error) {
        console.error('Error fetching users:', error);
      }
    },
  
    async fetchServices() {
      try {
        const res = await fetch('http://127.0.0.1:5000/admin/services', {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('access_token')}`
          }
        });
        if (res.ok) {
          const data = await res.json();
          this.services = data.services;
        } else {
          console.error('Failed to fetch services');
        }
      } catch (error) {
        console.error('Error fetching services:', error);
      }
    },
    async createService() {
      try {
        const res = await fetch('http://127.0.0.1:5000/admin/service', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${localStorage.getItem('access_token')}`
          },
          body: JSON.stringify({
            name: this.serviceName,
            description: this.serviceDescription,
            price: this.servicePrice,
            time_required: this.serviceTimeRequired
          })
        });
        if (res.ok) {
          const data = await res.json();
          console.log(data);
          alert('Service created successfully');
          // Clear the form
          this.serviceName = '';
          this.serviceDescription = '';
          this.servicePrice = '';
          this.serviceTimeRequired = '';
          // Close the modal
          $('#createServiceModal').modal('hide');
          // Fetch the updated list of services
          this.fetchServices();
        } else {
          console.error('Failed to create service');
        }
      } catch (error) {
        console.error('Error creating service:', error);
      }
    },
    async updateService() {
      try {
        const res = await fetch(`http://127.0.0.1:5000/admin/service/update/${this.editService.id}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${localStorage.getItem('access_token')}`
          },
          body: JSON.stringify({
            name: this.editService.name,
            description: this.editService.description,
            price: this.editService.price,
            time_required: this.editService.time_required
          })
        });
        if (res.ok) {
          const data = await res.json();
          console.log(data);
          alert('Service updated successfully');
          // Close the modal
          $('#editServiceModal').modal('hide');
          // Fetch the updated list of services
          this.fetchServices();
        } else {
          console.error('Failed to update service');
        }
      } catch (error) {
        console.error('Error updating service:', error);
      }
    },
    async deleteService(serviceId) {
      if (confirm('Are you sure you want to delete this service?')) {
        try {
          const res = await fetch(`http://127.0.0.1:5000/admin/service/delete/${serviceId}`, {
            method: 'DELETE',
            headers: {
              'Authorization': `Bearer ${localStorage.getItem('access_token')}`
            }
          });
          if (res.ok) {
            const data = await res.json();
            console.log(data);
            alert('Service deleted successfully');
            // Fetch the updated list of services
            this.fetchServices();
          } else {
            console.error('Failed to delete service');
          }
        } catch (error) {
          console.error('Error deleting service:', error);
        }
      }
    },
    async viewProfessional(user) {
      this.selectedProfessional = user;
      console.log("view",this.selectedProfessional)
      // Assuming you're using Bootstrap's modal
      const modal = new bootstrap.Modal(document.getElementById('professionalModal'));
      modal.show();
       },
    async approveProfessional(professionalId){console.log("approve")
      const res = await fetch(`http://127.0.0.1:5000/admin/approve-professional/${professionalId}`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('access_token')}`
        }}
      );
      if (res.ok){
        const data = await res.json();
        console.log(data);
        alert('Professional approved successfully');
        // Fetch the updated list of users
        this.fetchUsers();
      }

           
    },
    async rejectProfessional(professionalId){
      const res = await fetch(`http://127.0.0.1:5000/admin/reject-professional/${professionalId}`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('access_token')}`
        }}
      );
      if (res.ok){
        const data = await res.json();
        console.log(data);
        alert('Professional rejected successfully');
        // Fetch the updated list of users
        this.fetchUsers();
      }
      console.log("reject")},


      //Service -Requests
      async fetchServiceRequests() {
        const res = await fetch(`http://127.0.0.1:5000/admin/service-requests`, {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('access_token')}`
          }}
        );
        if(res.ok){
          const data = await res.json();
          this.serviceRequests = data.service_requests;
          console.log(this.serviceRequests);
          alert('Service requests fetched successfully');
        }
        console.log("fetching service requests",res);
      },
      
  
      // Filter professionals based on search query
      async getAllProfessionals() {
        try {
          const res = await fetch(`http://127.0.0.1:5000/admin/get-professionals`, {
            method: 'GET',
            headers: {
              'Authorization': `Bearer ${localStorage.getItem('access_token')}`
            }
          });
  
          if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
  
          const data = await res.json();
          console.log(data,'method')
          this.allProfessionals = data.professionals;
          console.log('allPr',this.allProfessionals)
        } catch (error) {
          console.error('Error searching professionals:', error);
        }
      },
      async searchProfessionals() {
        try {
          const res = await fetch(`http://127.0.0.1:5000/admin/search-professionals?query=${this.searchQuery}`, {
            method: 'GET',
            headers: {
              'Authorization': `Bearer ${localStorage.getItem('access_token')}`
            }
          });
  
          if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
  
          const data = await res.json();
          this.filteredProfessionals = data.professionals;
          this.allProfessionals=data.professionals;
        } catch (error) {
          console.error('Error searching professionals:', error);
        }
      },
      async blockProfessional(professionalId) {
        try {
          const res = await fetch(`http://127.0.0.1:5000/admin/block-professional/${professionalId}`, {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${localStorage.getItem('access_token')}`
            }
          });
  
          if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
  
          const data = await res.json();
          this.filteredProfessionals = data.professionals;
          alert('Professional blocked successfully');
        } catch (error) {
          console.error('Error searching professionals:', error);
        }
      },
      async unblockProfessional(professionalId) {
        try {
          const res = await fetch(`http://127.0.0.1:5000/admin/unblock-professional/${professionalId}`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${localStorage.getItem('access_token')}`
            }
          });
    
          if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
    
          // Refresh the professionals list after unblocking
          await this.searchProfessionals();
          alert('Professional unblocked successfully');
        } catch (error) {
          console.error('Error unblocking professional:', error);
          alert('Error unblocking professional');
        }
      },
      
  
    openEditModal(service) {
      this.editService = { ...service };
      $('#editServiceModal').modal('show');
    },
    showAllServices() {
      this.servicesLimit = this.services.length;
    },
    showAllUsers() {
      this.usersLimit = this.users.length;
    },
    async create_csv() {
       const res=await fetch(`http://127.0.0.1:5000/create-csv`,{
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('access_token')}`
        }
       })
       const task_id = (await res.json()).task_id
       const interval = setInterval(async() => {
        const res = await fetch(`${location.origin}/get-csv/${task_id}`)
        if (res.ok){
            console.log('data is ready')
            window.open(`${location.origin}/get-csv/${task_id}`)
            clearInterval(interval)
        }

    }, 100)
    
},
async create_service_requests_csv(){
  const res=await fetch(`http://127.0.0.1:5000/create-csv-service-requests`,{
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${localStorage.getItem('access_token')}`
    }
   })
   const task_id = (await res.json()).task_id
   const interval = setInterval(async() => {
    const res = await fetch(`${location.origin}/get-csv/${task_id}`)
    if (res.ok){
        console.log(task_id)
        console.log('data is ready')
        window.open(`${location.origin}/get-csv/${task_id}`)
        clearInterval(interval)
    }

}, 100)

},
  
  },
  mounted(){
    this.getAllProfessionals();
    
  },
  created() {
    this.fetchUsers();
    this.fetchServices();
    this.fetchServiceRequests();
    
  }
}