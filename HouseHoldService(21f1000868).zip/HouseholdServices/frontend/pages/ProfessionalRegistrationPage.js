// export default {
//     template: `
//       <div class="container py-5">
//   <div class="row justify-content-center">
//     <div class="col-md-6">
//       <div class="card border-0 shadow-lg" style="background-color: #1c1c1c; color: #f5f5f5;">
//         <div class="card-body p-4">
//           <h2 class="text-center mb-4" style="color: #ffffff;">Create Account</h2>
//           <form @submit.prevent="register">
            
//             <!-- Username Field -->
//             <div class="mb-3">
//               <input 
//                 type="text" 
//                 class="form-control rounded-pill" 
//                 placeholder="Username"
//                 v-model="username"
//                 required
//                 style="background-color: #333333; color: #ffffff; border: none;"
//               >
//             </div>

//             <!-- Email Field -->
//             <div class="mb-3">
//               <input 
//                 type="email" 
//                 class="form-control rounded-pill" 
//                 placeholder="Email"
//                 v-model="email"
//                 required
//                 style="background-color: #333333; color: #ffffff; border: none;"
//               >
//             </div>

//             <!-- Password Field -->
//             <div class="mb-3">
//               <input 
//                 type="password" 
//                 class="form-control rounded-pill" 
//                 placeholder="Password"
//                 v-model="password"
//                 required
//                 style="background-color: #333333; color: #ffffff; border: none;"
//               >
//             </div>

           

//             <!-- Register Button -->
//             <button 
//               type="submit" 
//               class="btn btn-primary btn-block rounded-pill"
//               style="background-color: #4CAF50; border-color: #4CAF50;"
//             >
//               Register
//             </button>
//           </form>
//         </div>
//       </div>
//     </div>
//   </div>
// </div>


//     `,
//     data() {
//         return {
//             username: '',
//             email: '',
//             password: '',
//             role: ''
//         }
//     },
//     methods: {
//         async register() {
//             const res = await fetch('http://127.0.0.1:5000/register-user',
//                 {
//                     method: 'POST',
//                     headers: { 'Content-Type': 'application/json' },
//                     body: JSON.stringify({ 'username': this.username, email: this.email, 'password': this.password, 'role': this.role })
//                 })

//             if (res.ok) {
//                 const data = await res.json()
//                 console.log(data)
//             }

//         }
//     }
// }