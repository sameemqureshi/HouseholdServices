import ServiceCard from "../components/ServiceCard.js";
import ServiceRequest from "../components/ServiceRequest.js";

export default {
    template: `
    <div class="home-page p-4">
        <div class="jumbotron text-center">
            <h1 class="display-4">Welcome to FixItPro</h1>
            <h2>Fast and professional service solutions.</h2>
            <p class="lead">Get started today and find the best professionals for your needs.</p>
            <a class="btn btn-primary btn-lg" href="#/register" role="button">Get Started Today</a>
        </div>
        <div class="text-center mb-4">
            <h2 class="mt-5">Home services at your doorstep</h2>
        </div>
       
        <div class="row">
            <div class="col-md-4 mb-4" v-for="service in services" :key="service.id">
                <ServiceCard :id="service.id" :name="service.name" :description="service.description" :price="service.price" :time_required="service.time_required">
                </ServiceCard>
            </div>
        </div>
    </div>
    `,
    data() {
      return {
       services: [],
       serviceRequests:[],
      }
    },
    methods: {
      openCompleteModal(requestId) {
          this.selectedRequest = this.serviceRequests.find(request => request.id === requestId);
          this.rating = 0; // Reset the rating
          const completeModal = new bootstrap.Modal(document.getElementById('completeModal'));
          completeModal.show();
      },

      async handleComplete() {
          if (!this.selectedRequest) return;

          console.log('Completed request with ID:', this.selectedRequest.id);
          const response = await fetch(`/user/service-request/close/${this.selectedRequest.id}`, {
              method: 'POST',
              headers: {
                  'Content-Type': 'application/json',
                  'Authorization': `Bearer ${this.$store.state.access_token}`
              },
              body: JSON.stringify({ rating: this.rating })
          });
          if (response.ok) {
              console.log("Service Request Closed");
              // Optionally, update the serviceRequests array to reflect the change
              this.serviceRequests = this.serviceRequests.filter(request => request.id !== this.selectedRequest.id);
              const completeModal = document.getElementById('completeModal');
            
                $('#completeModal').modal('hide')
            
          } else {
              console.error('Failed to complete service request');
          }
      }
  },
  

    async mounted(){
        const response = await fetch('/public/services', {
            method: 'GET',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${this.$store.state.access_token}`
            }
          });
          if (response.ok) {
            console.log('Services fetched successfully');
            const data = await response.json();
            this.services = data.services;
            console.log('Services fetched successfully', this.services);
          } else {
            console.error('Failed to fetch services');
          }
          const serviceRequestsResponse = await fetch('/user/service-request', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${this.$store.state.access_token}`
            }
        });
        if (serviceRequestsResponse.ok) {
            console.log('Service requests fetched successfully');
            const serviceRequestsData = await serviceRequestsResponse.json();
            this.serviceRequests = serviceRequestsData.service_requests;
            console.log('Service requests fetched successfully', this.serviceRequests);
        } else {
            console.error('Failed to fetch service requests');
        }
    
    },
    components: {
        ServiceCard,
        ServiceRequest
    }
  }