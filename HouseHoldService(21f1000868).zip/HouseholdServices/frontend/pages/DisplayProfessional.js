import ProfessionalCard from "../components/ProfessionalCard.js";
export default {
    props:['id'],
    template: `
  <div class="container mt-5">
  <div>
<div class="mb-3">
  <div class="input-group w-50">
    <input
      type="text"
      class="form-control"
      placeholder="Search Professionals"
      v-model="searchQuery"
    />
    <button @click="searchProfessionals" class="btn btn-primary">Search</button>
  </div>
</div>
</div>
  <div class="row justify-content-center">
    <div class="col-lg-10">
      <h2 class="text-center mb-4">Book Professionals</h2>
      <!-- Add gutters for spacing -->
      <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
        <div 
          v-for="professional in professionals" 
          :key="professional.id" 
          class="col d-flex justify-content-center"
        >
          <ProfessionalCard 
            :professional="professional" 
            :isAdmin="isAdmin"
            @book="handleBook" 
          />
        </div>
      </div>
    </div>
  </div>
</div>

`
,
    data() {
        return {
         searchQuery:'',
         professionals: [],
         isAdmin:'false'
        }
        },  
    async mounted(){
        const response = await fetch(`/public/service/${this.id}/professionals`, {
            method: 'GET',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${this.$store.state.access_token}`             }
          });
          if (response.ok) {
            const data = await response.json();
            this.professionals = data.professionals;
            this.isAdmin = 'false';
            console.log('Professionals fetched successfully', this.professionals);
          } else {
            console.error('Failed to fetch professionals');
          } 
    },
    components: {
        ProfessionalCard
    },
    methods:{
      async searchProfessionals() {
        console.log('Search query:', this.searchQuery);
        try {  
          const res = await fetch(`http://127.0.0.1:5000/public/service/${this.id}/search-professionals?query=${this.searchQuery}`, {
            method: 'GET',
            headers: {
              'Authorization': `Bearer ${localStorage.getItem('access_token')}`
            }
          });
      
          if (!res.ok) {
            const errorText = await res.text();
            throw new Error(`HTTP error! status: ${res.status}, message: ${errorText}`);
          }
      
          const data = await res.json();
          this.professionals = data.professionals;
        } catch (error) {
          console.error('Error searching services:', error);
        }
      },
        async handleBook(professionalId) {
            console.log('Booking professional with ID:', professionalId);
            try {
                console.log('Service ID:', this.id);
                const dateOfRequest = new Date().toISOString().slice(0, 19).replace('T', ' ');
                const response = await fetch('http://127.0.0.1:5000/user/service-request', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${this.$store.state.access_token}`
                    },
                    body: JSON.stringify({
                        service_id: this.id,
                        professional_id: professionalId,
                        remarks: 'Booking request',
                        date_of_request: dateOfRequest
                    })
                });
                if (response.ok) {
                    const data = await response.json();
                    console.log('Service request created successfully', data);
                    alert('Service request created successfully');
                } else {
                    const errorData = await response.json();
                    console.error('Failed to create service request', errorData);
                    alert('Failed to create service request: ' + errorData.msg);
                }
            } catch (error) {
                console.error('Error creating service request', error);
                alert('Error creating service request');
            }
        }
    }
}