export default {
  template:`
<div>
    <nav class="navbar navbar-expand-lg navbar-dark bg-gradient shadow-sm" style="background: linear-gradient(135deg, #000000, #434343);">
      <div class="container-fluid">
        <!-- Brand/Logo -->
        <router-link to="/" class="navbar-brand text-white fw-bold">FixItPro</router-link>

        <!-- Toggle Button for Mobile View -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Navbar Links -->
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <!-- Home Link -->
            <li class="nav-item">
              <router-link to="/" class="nav-link text-white">Home</router-link>
            </li>
             <!-- Register Link -->
            <li class="nav-item" v-if="!$store.state.loggedIn">
              <router-link to="/register" class="nav-link text-white">Register</router-link>
            </li>

            <!-- Login Links (Professional/User) -->
            <li class="nav-item" v-if="!$store.state.loggedIn">
              <router-link to="/login" class="nav-link text-white">Professional/User-Login</router-link>
            </li>

            <!-- Admin Login Link -->
            <li class="nav-item" v-if="!$store.state.loggedIn">
              <router-link to="/admin-login" class="nav-link text-white">Admin Login</router-link>
            </li>

           

            <!-- Admin Dashboard Link (Visible only to admins) -->
            <li class="nav-item" v-if="$store.state.loggedIn && $store.state.role === 'admin'">
              <router-link to="/admin-dashboard" class="nav-link text-white">Admin Dashboard</router-link>
            </li>

            <!-- Logout Button (Visible when logged in) -->
           
          <li class="nav-item" v-if="$store.state.loggedIn">
            <button class="btn btn-danger" @click="handleLogout">Logout</button>
          </li>
          </ul>
        </div>
      </div>
    </nav>
  </div>`,
  methods: {
    handleLogout() {
      this.$store.commit('logout');
      this.$router.push('/');
    }
  }
};

