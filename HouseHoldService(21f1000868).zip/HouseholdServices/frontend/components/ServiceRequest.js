export default {
    props: ['availableRequests','role'],
    template: `
      <div class="container-fluid bg-light p-4 rounded shadow-sm">
        <div class="d-flex justify-content-between align-items-center mb-4">
          <h2 v-if="availableRequests.length > 0" class="h4 text-dark fw-bold">
          <i class="bi bi-clipboard-data me-2"></i>
          Available Service Requests
        </h2>

          <span class="badge bg-primary rounded-pill">
            Total Requests: {{ availableRequests.length }}
          </span>
        </div>

        <div v-if="availableRequests.length > 0" class="table-responsive">
         <i class="bi bi-clipboard-data me-2"></i>
          <table class="table table-striped table-hover align-middle mb-0">
            <thead class="table-light">
              <tr>
                <th v-if="role === 'User'"class="text-uppercase small fw-bold text-secondary">Service Name</th> 
                <th v-if="role !='User'">Customer Name</th>
                <th v-if="role === 'User'">Professional Name</th>
                <th class="text-uppercase small fw-bold text-secondary">Date Requested</th>
                <th class="text-uppercase small fw-bold text-secondary">Status</th>
                <th class="text-uppercase small fw-bold text-secondary">Actions</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="request in availableRequests" :key="request.id">
                <td td v-if="role ==='User'">
                  <div class="d-flex align-items-center">
                      <i class="bi bi-tools text-primary"></i>
              
                    <span>{{ request.service_name }}</span>
                  </div>
                </td>
                <td v-if="role !='User'">
                <div class="d-flex align-items-center">
                  <div class="bg-secondary bg-opacity-10 rounded-circle p-2 me-2 text-center" 
                       style="width: 40px; height: 40px;">
                    <small class="fw-bold">{{ getInitials(request.customer_name) }}</small>
                  </div>
                  {{ request.customer_name }}
                </div>
              </td>
              <td v-if="role === 'User'">
                <div class="d-flex align-items-center">
                  <div>
                    <small class="fw-bold">{{ request.professional_name }}</small>
                  </div>
                  {{ request.Professional_name }}
                </div>
              </td>
                 <td>
                  <i class="bi bi-calendar me-2"></i>
                  {{ formatDate(role === 'User' ? request.date_requested : request.date_of_request) }}
                </td>
                <td>
                  <span :class="getStatusBadgeClass(request.status)" class="badge rounded-pill">
                    {{ request.status }}
                  </span>
                </td>
                <td>
                  <button v-if="role !='User'" @click="$emit('accept', request.Service_request_id)" class="btn btn-primary btn-sm">
                    <i class="bi bi-check-lg me-1"></i>
                    Accept
                  </button>
                   
                  <button v-if="role != 'User'" @click="$emit('reject', request.Service_request_id)" class="btn btn-danger btn-sm">
                    <i class="bi bi-check-lg me-1"></i>
                    Reject
                  </button>
               <button v-if="role === 'User' && request.status !== 'completed'" @click="$emit('complete', request.id)" class="btn btn-warning btn-sm">Complete</button> 
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <div v-else class="text-center py-5 bg-white border rounded">
          <i class="bi bi-inbox display-4 text-secondary mb-3"></i>
          <p class="text-muted mb-3">No available service requests.</p>
          <!-- <button class="btn btn-outline-primary" @click="$emit('fetch-requests')">
            <i class="bi bi-arrow-clockwise me-2"></i>
            Fetch Services 1
          </button> -->
        </div>
      </div>
    `,
    methods: {
      formatDate(date) {
        return new Date(date).toLocaleDateString('en-US', {
          year: 'numeric',
          month: 'short',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit'
        });
      },
      getInitials(name) {
        if (!name) return '';
        const names = name.split(' ');
        const initials = names.map(n => n.charAt(0).toUpperCase()).join('');
        return initials;
    },
      getStatusBadgeClass(status) {
        const statusClasses = {
          'pending': 'bg-warning text-dark',
          'accepted': 'bg-success',
          'completed': 'bg-info',
          'cancelled': 'bg-danger'
        };
        return statusClasses[status.toLowerCase()] || 'bg-secondary';
      }
    },
}
