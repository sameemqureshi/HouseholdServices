export default {
  props: ['professional'],
  data() {
    return {
      userRole: localStorage.getItem('role'),
      isFading: false, // Reactive property for fade effect
    };
  },
  methods: {
    handleBook(professionalId) {
      this.isFading = true; // Trigger the fade effect
      this.$emit('book', professionalId); // Emit the book event

      // Reset or remove the card after the fade effect completes
      setTimeout(() => {
        this.isFading = false;
      }, 1500); // Match duration to CSS transition
    },
  },
  template: `
    <div 
      class="card h-100 shadow-lg" 
      :class="{ 'fade-out': isFading }" 
      style="background: linear-gradient(145deg, #2a2a2a, #1a1a1a); color: #ffffff; border-radius: 16px;"
    >
      <div class="card-body d-flex flex-column">
        <div class="text-center mb-3">
          <!-- Avatar Placeholder -->
          <div 
            class="avatar-placeholder mb-2" 
            style="width: 80px; height: 80px; background-color: #007bff; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 2rem; font-weight: bold; color: white;"
          >
            {{ professional.username.charAt(0).toUpperCase() }}
          </div>
          <h5 class="card-title text-primary mb-0">{{ professional.username }}</h5>
        </div>
        
        <!-- Professional Info -->
        <div class="mb-3">
          <p class="card-text text-muted mb-2"><i class="fas fa-envelope me-2"></i>{{ professional.email }}</p>
          <p class="card-text text-muted"><i class="fas fa-briefcase me-2"></i>{{ professional.experience_years }} years</p>
          <p class="card-text text-muted"><i class="fas fa-briefcase me-2"></i> {{ professional.rating }} ⭐️</p>
          <p class="card-text text-muted">
            <i class="fas fa-briefcase me-2"></i>
            <span v-for="n in 5" :key="n" :class="['bi', professional.rating >= n ? 'bi-star-fill' : 'bi-star']" :style="professional.rating >= n ? { color: 'gold' } : { color: 'lightgray' }"></span>
          </p>
          <p class="card-text text-muted"><i class="fas fa-briefcase me-2"></i>{{ professional.address }} </p>
        </div>

        <!-- Action Buttons -->
        <div class="mt-auto d-flex justify-content-between gap-2">
          <!-- Approve & Reject Buttons for Admin -->
          <button 
            v-if="userRole === 'Admin'"
            class="btn btn-success btn-sm flex-grow-1"
            @click="$emit('approve', professional.id)"
          >
            <i class="fas fa-check me-2"></i>Approve
          </button>
          <button 
            v-if="userRole === 'Admin'"
            class="btn btn-danger btn-sm flex-grow-1"
            @click="$emit('reject', professional.id)"
          >
            <i class="fas fa-times me-2"></i>Reject
          </button>

          <!-- Book Button for User -->
          <button 
            v-else-if="userRole === 'User'"
            class="btn btn-primary btn-sm flex-grow-1"
            @click="handleBook(professional.id)"
          >
            <i class="fas fa-calendar-check me-2"></i>Book
          </button>
        </div>
      </div>
    </div>
  `,
  style: `
    .fade-out {
      opacity: 0;
      transform: scale(0.8); /* Shrink the card slightly */
      transition: opacity 1.5s ease-in-out, transform 1.5s ease-in-out; /* Smooth fade and shrink */
    }
    .fade-out-hidden {
      display: none; /* Hide the element after the animation */
    }
    .bi-star-fill {
      color: gold;
    }
    .bi-star {
      color: lightgray;
    }
  `,
};
