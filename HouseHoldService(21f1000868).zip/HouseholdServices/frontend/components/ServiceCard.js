export default {
    props: ['name', 'id', 'description', 'price', 'time_required'],
    template: `
      <div class="card mb-4 shadow-lg hover-card"
        style="background: linear-gradient(145deg, #1a1a1a, #0a0a0a); 
               color: #ffffff; 
               border-radius: 20px; 
               border: 1px solid rgba(255,255,255,0.08);
               transition: all 0.3s ease;">
        <div class="card-body p-4" 
             style="background: radial-gradient(circle at top right, rgba(41, 41, 41, 0.8), transparent);">
          <h5 class="card-title mb-4"
            style="font-weight: 600; 
                   text-transform: uppercase; 
                   letter-spacing: 2px; 
                   color: #ffffff;
                   border-bottom: 2px solid rgba(255,255,255,0.08);
                   padding-bottom: 12px;
                   background: linear-gradient(to right, #fff, #a0a0a0);
                   -webkit-background-clip: text;
                   background-clip: text;
                   color: transparent;">
            {{ name }}
          </h5>
          
          <div class="card-info mb-4">
            <p class="card-text mb-3"
              style="font-size: 0.9rem; 
                     color: rgba(255,255,255,0.9);
                     line-height: 1.7;
                     background: rgba(255,255,255,0.05);
                     padding: 12px;
                     border-radius: 12px;
                     border: 1px solid rgba(255,255,255,0.05);">
              <span style="color: #B4B4B4;">Description:</span> {{ description }}
            </p>
            
            <p class="card-text mb-3"
              style="font-size: 0.9rem; 
                     color: rgba(255,255,255,0.9);
                     padding: 8px 12px;
                     border-radius: 8px;
                     background: rgba(255,255,255,0.03);
                     border: 1px solid rgba(255,255,255,0.05);">
              <span style="color: #B4B4B4;">Price:</span> 
              <span class="badge ms-2" 
                    style="background: linear-gradient(135deg, #2b2b2b, #1a1a1a);
                           padding: 6px 12px;
                           border-radius: 20px;
                           font-weight: 500;
                           border: 1px solid rgba(255,255,255,0.1);">
                {{ price }}
              </span>
            </p>
            
            <p class="card-text mb-4"
              style="font-size: 0.9rem; 
                     color: rgba(255,255,255,0.9);
                     padding: 8px 12px;
                     border-radius: 8px;
                     background: rgba(255,255,255,0.03);
                     border: 1px solid rgba(255,255,255,0.05);">
              <span style="color: #B4B4B4;">Time Required:</span>
              <span class="badge ms-2" 
                    style="background: linear-gradient(135deg, #2b2b2b, #1a1a1a);
                           padding: 6px 12px;
                           border-radius: 20px;
                           font-weight: 500;
                           border: 1px solid rgba(255,255,255,0.1);">
                {{ time_required }} hours
              </span>
            </p>
          </div>
          
          <button class="btn w-100"
            @click="viewProfessionals"
            style="background: linear-gradient(135deg, #ffffff, #e0e0e0);
                   border: none;
                   padding: 14px;
                   font-weight: 600;
                   letter-spacing: 1px;
                   text-transform: uppercase;
                   font-size: 0.9rem;
                   color: #000000;
                   transition: all 0.3s ease;
                   border-radius: 12px;">
            Browse Professionals
          </button>
        </div>
        
      </div>

    `,
    methods: {
      viewProfessionals() {
        this.$router.push(`/service/${this.id}/professionals`);
      }
    },
    mounted() {
      const style = document.createElement('style');
      style.textContent = `
        .hover-card {
          transform: translateY(0);
          transition: all 0.3s ease;
          box-shadow: 0 10px 30px rgba(0,0,0,0.4);
        }
        .hover-card:hover {
          transform: translateY(-5px);
          box-shadow: 0 20px 40px rgba(0,0,0,0.5) !important;
          border-color: rgba(255,255,255,0.12);
        }
        .btn:hover {
          transform: scale(1.02);
          box-shadow: 0 8px 20px rgba(0,0,0,0.3);
          background: linear-gradient(135deg, #ffffff, #f0f0f0) !important;
        }
        .badge {
          box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        }
      `;
      document.head.appendChild(style);
    }
  }