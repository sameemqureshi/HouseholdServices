const store=new Vuex.Store({
    state: {
        //like data
        access_token: null,
        role:null,
        loggedIn:false,
        user_id:null,
        username:null
      
    },
    mutations: {
        //functions that change state
        setUser(state) {
            try{
             if (JSON.parse(localStorage.getItem('user'))){
                const user = JSON.parse(localStorage.getItem('user'));
                state.access_token = user.access_token;
                state.role = user.role;
                state.loggedIn = true;
                state.user_id = user.user_id;
                state.username = user.username;
             }
            } catch {
                console.warn('not logged in')
        }         
        },

        logout(state){
            state.auth_token = null;
            state.role = null;
            state.loggedIn = false;
            state.user_id = null;
            localStorage.removeItem('user')
            localStorage.removeItem('access_token')
            localStorage.removeItem('role')
        }
      
    },
    actions:{
        // can be async
         
    }
})

store.commit('setUser')
export default store;