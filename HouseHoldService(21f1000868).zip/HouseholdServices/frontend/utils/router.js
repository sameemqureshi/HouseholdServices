
import LoginPage from '../pages/LoginPage.js';
import RegisterPage from '../pages/RegisterPage.js';
import AdminDashboard from '../pages/AdminDashboard.js';
import LoginUser from '../pages/LoginUser.js';
import UserHome from '../pages/UserHome.js';
import ProfessionalHome from '../pages/ProfessionalHome.js';
import DisplayProfessional from '../pages/DisplayProfessional.js';
import store from './store.js';
import Home from '../pages/Home.js';
// const Home = {
//     template:`
    
//     `
// }

const routes=[
    {path: '/',
    component: Home},
    {path:'/register',component:RegisterPage}, 
    {path:'/admin-login',component:LoginPage},
    {path:'/login',component:LoginUser},
    {path:'/admin-dashboard',component:AdminDashboard,meta: {requiresLogin: true, role: 'admin'}},
    {path:'/userHome',component:UserHome,meta:{requiresLogin: true,role: 'User'}},
    {path:'/professionalHome',component:ProfessionalHome,meta:{requiresLogin: true,role: 'Professional'}},
    {path:'/service/:id/professionals',component:DisplayProfessional,props:true , meta:{requiresLogin: true,role: 'User'}},

    ]


const vueRouter = new VueRouter({   
    routes
}) 
// navigation guards
vueRouter.beforeEach((to, from, next) => {
    if (to.matched.some((record) => record.meta.requiresLogin)){
        if (!store.state.loggedIn){
            next({path : '/login'})
        } else if (to.meta.role && to.meta.role != store.state.role){
            alert('role not authorized')
             next({path : '/'})
        } else {
            next();
        }
    } else {
        next();
    }
})

export default vueRouter